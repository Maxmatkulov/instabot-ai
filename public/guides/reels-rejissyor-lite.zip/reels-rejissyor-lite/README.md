# Reels Rejissyor Lite — o'rnatish

## Claude Code (kompyuterda)
1. Papkani ko'chiring:
   - Mac/Linux: `~/.claude/skills/reels-rejissyor-lite/`
   - Windows: `C:\Users\<siz>\.claude\skills\reels-rejissyor-lite\`
2. Claude Code'ni qayta oching.
3. Yozing: `reels-rejissyor-lite bilan "..." mavzusida reels ssenariysi tuz`

## Claude.ai (brauzer yoki ilova)
1. Settings -> Capabilities -> Skills bo'limiga kiring.
2. Shu papkani zip qilib yuklang (yoki tayyor zip faylni).
3. Chatda yozing: `reels-rejissyor-lite skilli bilan reels ssenariysi tuz: mavzu ...`

Skill ichidagi SKILL.md oddiy matn fayl: ochib o'qishingiz va o'zingizga moslashingiz mumkin.

Muallif: @mashrabbek.maxmatkulov · Telegram: @mashrabbekmaxmatkulov
