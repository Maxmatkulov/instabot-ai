# Reels Rejissyor PRO — o'rnatish

Ichida:
- `SKILL.md` — Claude uchun rejissyor qoidalari va to'liq ish tartibi.
- `template/` — tayyor Remotion loyihasi (do'ppili Claude, sahnalar, subtitr, o'tishlar). Namuna sifatida 1-qism videosining sahnalari turibdi.
- `tools/` — `autoalign.py` (so'zma-so'z vaqt), `lipsync.py` (og'iz harakati), `mixgen.py` (SFX + musiqa), `render.sh` (tez render).

## O'rnatish (Claude Code)
1. Papkani `~/.claude/skills/reels-rejissyor-pro/` ga ko'chiring (Windows: `C:\Users\<siz>\.claude\skills\`).
2. Kerak: Node.js 18+, Python 3 (`pip install numpy scipy`), ffmpeg.
3. Claude Code'da yozing: `reels-rejissyor-pro bilan "..." mavzusida reels qil. Ovoz: ovoz.mp3`

Claude ssenariy yozadi, siz ovozni ElevenLabs'da yaratib tashlaysiz, qolganini u o'zi yig'adi.

## Litsenziya
- Paketni shaxsiy va o'z biznesingiz uchun ishlating. Qayta sotish va tarqatish mumkin emas.
- Remotion: shaxslar va 3 kishigacha bo'lgan kompaniyalar uchun bepul. Kattaroq kompaniyalar remotion.dev saytida litsenziya oladi.

Savol: Telegram @mmn0300 · Kanal: @mashrabbekmaxmatkulov
