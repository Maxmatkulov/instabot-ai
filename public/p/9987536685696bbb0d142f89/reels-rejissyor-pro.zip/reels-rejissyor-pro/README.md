# Rejissyor studiyasi PRO

Bu paket bilan ovozingizni yozasiz, qolgan videoni Claude o'zi yasab beradi:
ssenariy, so'zma-so'z yozuv, multfilm Claude personaji, tovushlar va tayyor MP4.

## Nima kerak (bir marta)
- **Claude Code** (kompyuteringizda)
- **Node.js** (nodejs.org dan "LTS" ni yuklab o'rnating)
- **Python 3** va **ffmpeg**
(Qaysi biri yo'q bo'lsa, Claude'ga "buni o'rnatib ber" deng, u o'zi qiladi.)

## 3 qadam
1. Shu papkani (`reels-rejissyor-pro`) kompyuteringizdagi `.claude/skills/` ichiga tashlang.
   - Windows: `C:\Users\SIZNING_ISMINGIZ\.claude\skills\`
   - Mac: `~/.claude/skills/`
2. Claude Code'ni oching.
3. Shuni yozing (mavzuni o'zingiznikiga almashtiring):

   `reels-rejissyor-pro bilan "mavzu" haqida reels qil`

Claude sizga ovoz uchun matn beradi. Uni ElevenLabs'da ovozga aylantiring, faylni Claude'ga bering:

   `Mana ovoz: ovoz.mp3`

Qolgan hammasini u o'zi qiladi va tayyor video faylni beradi.

## Ichida nima bor
- `SKILL.md`: Claude uchun yo'riqnoma (rejissyor qoidalari).
- `template/`: tayyor video loyihasi (personaj, sahnalar, yozuvlar).
- `tools/`: yordamchi dasturlar (so'zlarni ovozga moslash, tovush, tez render).

## Foydalanish shartlari
- O'zingiz va o'z biznesingiz uchun ishlating. Boshqalarga sotish yoki tarqatish mumkin emas.
- Remotion (video dasturi): yakka shaxs va 3 kishigacha bo'lgan kompaniyalar uchun bepul. Kattaroq kompaniya remotion.dev dan litsenziya oladi.

Savol bo'lsa: Telegram @mmn0300 · Kanal: @mashrabbekmaxmatkulov
