#!/usr/bin/env python3
# Ovoz + SFX + musiqa miksi. ishlatish: mixgen.py voice.wav events.json out_raw.wav [dur_sec]
# events.json: [{"t": 1.2, "sfx": "pop"|"whoosh"|"ding"|"buzz"|"tick"|"boom"|"clap"|"thud", "g": 1.0, "n": 8, "dt": 0.09}]
import sys, json, numpy as np
from scipy.io import wavfile
from scipy.signal import butter, lfilter
vp, ep, op = sys.argv[1:4]
v_sr, v = wavfile.read(vp); v = v.astype(np.float32) / 32768
if v.ndim > 1: v = v.mean(1)
sr = 44100
if v_sr != sr: raise SystemExit('voice 44100 Hz bo\'lsin')
D = float(sys.argv[4]) if len(sys.argv) > 4 else len(v) / sr + 1.0
N = int(D * sr); rng = np.random.default_rng(3)
voice = np.zeros(N, np.float32); voice[:min(N, len(v))] = v[:N]
def place(buf, x, t, g=1.0):
    i = int(t * sr); j = min(N, i + len(x))
    if 0 <= i < N: buf[i:j] += x[:j - i] * g
def whoosh():
    n = int(.45 * sr); t = np.arange(n) / sr; b, a = butter(2, [400 / (sr / 2), 5000 / (sr / 2)], 'band')
    return (lfilter(b, a, rng.standard_normal(n)) * np.sin(np.pi * t / .45) ** 2 * 0.6).astype(np.float32)
def pop():
    n = int(.18 * sr); t = np.arange(n) / sr; f = 700 * np.exp(-t * 18) + 180
    return (np.sin(2 * np.pi * np.cumsum(f) / sr) * np.exp(-t * 22) * 0.9).astype(np.float32)
def ding():
    n = int(.7 * sr); t = np.arange(n) / sr
    return ((np.sin(2 * np.pi * 1318 * t) + 0.5 * np.sin(2 * np.pi * 1976 * t)) * np.exp(-t * 6) * 0.35).astype(np.float32)
def buzz():
    n = int(.35 * sr); t = np.arange(n) / sr
    return (np.sign(np.sin(2 * np.pi * 110 * t)) * np.exp(-t * 7) * 0.3).astype(np.float32)
def tick():
    n = int(.05 * sr); t = np.arange(n) / sr
    return (rng.standard_normal(n) * np.exp(-t * 110) * 0.5).astype(np.float32)
def boom():
    n = int(.9 * sr); t = np.arange(n) / sr; f = 90 * np.exp(-t * 4) + 32
    body = np.sin(2 * np.pi * np.cumsum(f) / sr) * np.exp(-t * 4.5)
    b, a = butter(2, 2500 / (sr / 2)); hit = lfilter(b, a, rng.standard_normal(n)) * np.exp(-t * 30) * 0.5
    return ((body + hit) * 0.95).astype(np.float32)
def clap():
    n = int(.25 * sr); t = np.arange(n) / sr; b, a = butter(2, [800 / (sr / 2), 6000 / (sr / 2)], 'band')
    return (lfilter(b, a, rng.standard_normal(n)) * np.exp(-t * 35) * 1.1).astype(np.float32)
def thud():
    n = int(.3 * sr); t = np.arange(n) / sr; f = 160 * np.exp(-t * 20) + 60
    return (np.sin(2 * np.pi * np.cumsum(f) / sr) * np.exp(-t * 14) * 0.9).astype(np.float32)
F = {'whoosh': whoosh(), 'pop': pop(), 'ding': ding(), 'buzz': buzz(), 'tick': tick(), 'boom': boom(), 'clap': clap(), 'thud': thud()}
sfx = np.zeros(N, np.float32)
for e in json.load(open(ep)):
    place(sfx, F[e['sfx']], e['t'], e.get('g', 1.0))
    if e['sfx'] == 'tick':
        for k in range(1, e.get('n', 8)): place(sfx, F['tick'], e['t'] + k * e.get('dt', 0.09), 0.7)
beat = 60 / 100; mus = np.zeros(N, np.float32)
k = np.arange(int(.25 * sr)) / sr; kick = (np.sin(2 * np.pi * np.cumsum(120 * np.exp(-k * 25) + 45) / sr) * np.exp(-k * 9)).astype(np.float32)
h = (rng.standard_normal(int(.05 * sr)) * np.exp(-np.arange(int(.05 * sr)) / sr * 90) * 0.25).astype(np.float32)
bt = 0
while bt < D:
    place(mus, kick, bt, 0.9); place(mus, h, bt + beat / 2, 0.8); bt += beat
notes = [55, 55, 65.4, 49]
for bar in range(int(D / (beat * 4)) + 1):
    f0 = notes[bar % 4]
    for q in range(8):
        t0 = bar * beat * 4 + q * beat / 2; n = int(.22 * sr); t = np.arange(n) / sr
        place(mus, (np.sin(2 * np.pi * f0 * (2 if q % 2 else 1) * t) * np.exp(-t * 7) * 0.5).astype(np.float32), t0)
        if q % 2 == 0: place(mus, (np.sin(2 * np.pi * f0 * 8 * t) * np.exp(-t * 12) * 0.12).astype(np.float32), t0 + beat / 4)
ve = np.abs(voice); w = int(.08 * sr); ve = np.convolve(ve, np.ones(w) / w, 'same'); duck = 1 - 0.55 * np.clip(ve / 0.08, 0, 1)
mus *= duck.astype(np.float32); mus *= np.clip(np.minimum(np.arange(N) / (sr * .5), (N - np.arange(N)) / (sr * 2.0)), 0, 1)
rms = lambda x: np.sqrt(np.mean(x[np.abs(x) > 1e-4] ** 2))
mus *= rms(voice) * 10 ** (-19 / 20) / rms(mus); sfx *= 0.55
mix = voice + mus + sfx; mix /= max(1, np.max(np.abs(mix)) / 0.84)
wavfile.write(op, sr, (mix * 32767).astype(np.int16)); print('ok', round(D, 2), 's')
