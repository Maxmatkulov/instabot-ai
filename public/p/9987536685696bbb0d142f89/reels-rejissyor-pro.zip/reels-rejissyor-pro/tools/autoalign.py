#!/usr/bin/env python3
# Ovozni skript bilan so'zma-so'z moslash (ASR'siz).
# ishlatish: autoalign.py voice.wav script.txt out_words.json [--groups "t0-t1,t0-t1,..."]
# script.txt: har qator = bitta gap (subtitr guruhi). So'z ichida "aytilishi>ekranda" yozish mumkin: Klod>Claude
import sys, json, re, numpy as np, wave
from scipy.signal import find_peaks
wav, scr, out = sys.argv[1], sys.argv[2], sys.argv[3]
w = wave.open(wav); sr = w.getframerate(); ch = w.getnchannels()
x = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768
if ch > 1: x = x.reshape(-1, ch).mean(1)
hop = int(sr * 0.01); env = np.array([np.sqrt(np.mean(x[i:i + hop] ** 2)) for i in range(0, len(x) - hop, hop)])
env = np.convolve(env, np.ones(5) / 5, 'same'); thr = max(np.percentile(env, 20) * 2.5, env.max() * 0.04)
lines = [l.strip() for l in open(scr, encoding='utf8') if l.strip()]
V = 'aeiouoʻAEIOU'
def syl(t):
    t = t.split('>')[0].lower().replace("o'", 'o').replace("g'", 'g')
    if re.fullmatch(r'[A-Z]{2,}', t.split('>')[0]): return len(t) * 1.2
    return max(1, sum(1 for c in t if c in 'aeiouy'))
if '--groups' in sys.argv:
    G = [tuple(map(float, g.split('-'))) for g in sys.argv[sys.argv.index('--groups') + 1].split(',')]
else:
    voiced = env > thr; segs = []; i = 0; n = len(voiced)
    while i < n:
        if voiced[i]:
            j = i
            while j < n and (voiced[j] or (j + 25 < n and voiced[j:j + 25].any())): j += 1  # 0.25 s dan qisqa pauza birlashadi
            segs.append([i * 0.01, j * 0.01]); i = j
        else: i += 1
    segs = [s for s in segs if s[1] - s[0] > 0.12]
    # segmentlarni gaplar soniga moslash: ortiqchasini eng qisqa pauzadan birlashtiramiz
    while len(segs) > len(lines):
        gaps = [segs[k + 1][0] - segs[k][1] for k in range(len(segs) - 1)]; k = int(np.argmin(gaps))
        segs[k][1] = segs[k + 1][1]; del segs[k + 1]
    while len(segs) < len(lines):  # kam bo'lsa — eng uzun segmentni bo'g'in nisbatida bo'lamiz
        k = int(np.argmax([s[1] - s[0] for s in segs])); s0, s1 = segs[k]; m = (s0 + s1) / 2
        segs[k] = [s0, m - 0.05]; segs.insert(k + 1, [m + 0.05, s1])
    G = [tuple(s) for s in segs]
words = []
for g, (line, (t0, t1)) in enumerate(zip(lines, G)):
    toks = line.split(); sy = [syl(t) for t in toks]; tot = sum(sy) + 0.4 * (len(toks) - 1); t = t0; dur = t1 - t0
    for k, (tok, s) in enumerate(zip(toks, sy)):
        d = dur * s / tot; disp = tok.split('>')[-1]
        words.append({'w': tok.split('>')[0], 'd': disp, 'g': g, 'k': k, 's': round(t, 3), 'e': round(t + d, 3)}); t += d + dur * 0.4 / tot
json.dump(words, open(out, 'w', encoding='utf8'), ensure_ascii=False)
for g, (a, b) in enumerate(G): print(f'{g:2d} {a:6.2f}-{b:6.2f}  {lines[g][:60]}')
