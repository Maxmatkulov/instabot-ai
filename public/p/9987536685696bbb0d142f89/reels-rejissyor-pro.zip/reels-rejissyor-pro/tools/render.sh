#!/bin/bash
set -e
P=$(cd "$1" && pwd); OUT=${2:-$P/out/final.mp4}; cd "$P"; mkdir -p out/parts
N=$(npx remotion compositions src/index.ts 2>/dev/null | awk '$1=="Reel"{print $4}')
[ -z "$N" ] && { echo "Reel topilmadi"; exit 1; }
STEP=150; i=0; : > out/list.txt; t0=$(date +%s)
for ((s=0; s<N; s+=STEP)); do
  e=$((s+STEP-1)); [ $e -ge $N ] && e=$((N-1))
  f=out/parts/c$(printf %03d $i)_${s}_${e}.mp4
  if [ ! -s "$f" ]; then
    npx remotion render src/index.ts Reel "$f.tmp.mp4" --frames=$s-$e --muted --gl=angle \
      --concurrency=2 --x264-preset=veryfast --log=error && mv "$f.tmp.mp4" "$f"
  fi
  echo "file 'parts/$(basename $f)'" >> out/list.txt; echo "bo'lak $i ($s-$e) tayyor"; i=$((i+1))
done
ffmpeg -y -loglevel error -f concat -safe 0 -i out/list.txt -i public/mix.wav -map 0:v -map 1:a \
  -c:v copy -c:a aac -b:a 192k -shortest -movflags +faststart "$OUT"
echo "TAYYOR: $OUT  ($(( $(date +%s)-t0 ))s)"
ffmpeg -i "$OUT" -af ebur128 -f null - 2>&1 | grep "I:" | tail -1
