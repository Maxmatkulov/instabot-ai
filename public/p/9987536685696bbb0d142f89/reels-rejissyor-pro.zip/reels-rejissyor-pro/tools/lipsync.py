#!/usr/bin/env python3
# ishlatish: lipsync.py voice.wav out.json  -> har 30fps kadr uchun [a, c]: a=og'iz ochilishi 0..1, c=shakl 0(yumaloq)..1(keng)
import sys, json, numpy as np, wave
w = wave.open(sys.argv[1]); sr = w.getframerate(); ch = w.getnchannels()
x = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768
if ch > 1: x = x.reshape(-1, ch).mean(1)
n = int(len(x) / sr * 30) + 1; win = int(sr * 0.04); A = []; C = []
for i in range(n):
    c0 = int(i / 30 * sr); seg = x[max(0, c0 - win): c0 + win]
    if len(seg) < 64: A.append(0); C.append(.5); continue
    A.append(float(np.sqrt((seg ** 2).mean())))
    sp = np.abs(np.fft.rfft(seg * np.hanning(len(seg)))); fr = np.fft.rfftfreq(len(seg), 1 / sr)
    m = (fr > 300) & (fr < 4000); C.append(float((sp[m] * fr[m]).sum() / (sp[m].sum() + 1e-9)))
A = np.array(A); C = np.array(C)
A = np.clip(A / (np.percentile(A, 96) + 1e-9), 0, 1) ** 0.8
A[A < 0.06] = 0
act = A > .2
lo, hi = np.percentile(C[act], 10), np.percentile(C[act], 90)
C = np.clip((C - lo) / (hi - lo + 1e-9), 0, 1)
out = [[round(float(a), 3), round(float(c), 3)] for a, c in zip(A, C)]
json.dump(out, open(sys.argv[2], 'w'))
print(len(out), 'kadr', 'o\'rtacha a=%.2f' % A.mean(), 'c=%.2f' % C[A > .2].mean())
