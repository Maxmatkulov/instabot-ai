# Rejissyor studiyasi PRO: to'liq yo'riqnoma

Bu yo'riqnoma noldan boshlaydi. Kompyuterda hech narsa o'rnatmagan bo'lsangiz ham, qadamma-qadam bajarsangiz, o'z birinchi videongizni yasaysiz.

**Qancha vaqt ketadi:** birinchi marta o'rnatish 40-60 daqiqa (bir marta). Keyingi har video: ssenariy 10 daqiqa, ovoz 10 daqiqa, video yig'ish va render 15-20 daqiqa.

**Muhim:** qadamlarni tartib bilan bajaring. Biror joyda tushunmasangiz yoki xato chiqsa, xatoni nusxalab Claude'ga yozing: "Mana xato, tuzat". U o'zi hal qiladi.

---

## Mundarija

1. Bu nima va qanday ishlaydi
2. Nimalar kerak (ro'yxat) va qayerda ishlaymiz
3. O'rnatish: Windows
4. O'rnatish: Mac
5. Paketni joyiga qo'yish
6. Tekshiruv: hammasi ishlayaptimi?
7. Birinchi videoni yasash (qadam-baqadam)
8. Video ichini o'zgartirish
9. Xatolar va ularning yechimi
10. Havolalar ro'yxati

---

## 1. Bu nima va qanday ishlaydi

Siz video yasamaysiz. Siz **rejissyorsiz**: mavzu aytasiz va ovoz yozasiz. Qolgan ishni Claude qiladi.

Ish tartibi, 6 qadam:

1. Siz Claude'ga mavzu aytasiz.
2. Claude hook (birinchi gap) va ssenariy yozadi. Siz tanlaysiz.
3. Claude ovoz uchun matn beradi. Siz uni ovozga aylantirasiz (ElevenLabs'da yoki o'z ovozingiz bilan).
4. Siz ovoz faylini Claude'ga berasiz.
5. Claude so'zlarni ovozga moslaydi, sahnalarni chizadi, tovushlarni qo'yadi.
6. Claude tayyor videoni (MP4) beradi.

![Ish tartibi](rasm/01-ish-tartibi.png)


Ichidagi sehr: personaj (do'ppili Claude) og'zini ovozingizga mos ochadi, subtitr so'zma-so'z yonadi, tovush effektlari va musiqa o'z joyiga tushadi. Hammasi tayyor shablonda.

---

## 2. Nimalar kerak (ro'yxat) va qayerda ishlaymiz

| Nima | Nega kerak | Pulmi? |
|---|---|---|
| **Claude hisobi** (claude.ai) | Claude Code shunga kiradi | Claude Code uchun pullik reja (Pro yoki Max) yoki API hisobi kerak. Narx o'zgarib turadi: claude.com/pricing |
| **Claude Code** | Bu kompyuteringizdagi Claude, fayllar bilan ishlaydi | Hisobingizga kiradi |
| **Node.js** | Video dasturi (Remotion) shunda ishlaydi | Bepul |
| **Python 3** | So'zlarni ovozga moslash dasturlari | Bepul |
| **ffmpeg** | Ovoz va videoni qayta ishlaydi | Bepul |
| **Git for Windows** (faqat Windows) | Claude Code Windows'da shuni talab qiladi | Bepul |
| **Ovoz** | Videoning ovozi | O'z ovozingiz bepul. ElevenLabs: bepul reja cheklangan, yaxshiroq sifat uchun pullik reja kerak bo'lishi mumkin |

Kompyuter: oddiy noutbuk yetadi. Kamida 8 GB xotira (RAM) tavsiya qilinadi, bo'sh joy 5 GB. Videokarta shart emas.

### Qayerda ishlaymiz (muhim, avval shuni o'qing)

Bu ishning hammasi **terminalda** (qora oyna) bo'ladi. Windows'da u `cmd`, Mac'da `Terminal` deb ataladi. Brauzerdagi Claude (claude.ai) bu ishda **kerak emas**: video faqat kompyuteringizdagi Claude Code orqali yasaladi.

Ish davomida 3 ta oyna ochiq turadi. Pastdagi rasmga qarang:

- **1-oyna, terminal.** Bu yerda **buyruq** yoziladi (`node -v`, `npm install...`, `claude`).
- **2-oyna, Claude ichida.** `claude` deb yozgach, **xuddi shu qora oynada** Claude ochiladi. Endi buyruq emas, **oddiy gap** yoziladi.
- **3-oyna, papka.** Ovoz faylini shu yerga tashlaysiz, tayyor videoni shu yerdan olasiz.

![Uchta oyna](rasm/09-oynalar.png)

**Qaysi dasturda ochish mumkin?**

| Variant | Qanday ochiladi | Kimga |
|---|---|---|
| **Terminal (cmd)**, tavsiya | Windows: Start, `cmd` deb yozing. Yoki papka ichida manzil qatoriga `cmd` yozing. Mac: Terminal dasturi | Hamma uchun. Yo'riqnoma shu usul bo'yicha yozilgan |
| **VS Code** ichidagi terminal | VS Code'da papkani oching (File, Open Folder), keyin menyudan **Terminal, New Terminal** | VS Code'ni biladiganlar uchun. Keyin hammasi xuddi shunday |
| **Claude dasturining** o'zi | Boshqa oyna. Bu yo'riqnomadagi qadamlar shunga yozilmagan | Boshlovchilarga tavsiya qilmaymiz |

Bilmasangiz, **faqat terminal (cmd)** dan foydalaning. Boshqasi shart emas.


---

## 3. O'rnatish: Windows

Hamma narsani tartib bilan o'rnating. Har birini o'rnatgach **kompyuterni qayta ishga tushirish shart emas**, lekin yangi terminal oynasi oching.

**Terminal nima?** Qora oyna, unga buyruq yoziladi. Ochish: Start tugmasini bosing, `cmd` deb yozing, Enter bosing.

### 3.1. Git for Windows

📍 **Qayerda:** brauzerda (sayt), keyin yuklangan fayl.

1. `git-scm.com/download/win` ga kiring.
2. Yuklangan faylni oching va hamma savolga **Next** bosib boraveng (o'zgartirish shart emas), oxirida **Install**.

### 3.2. Node.js

📍 **Qayerda:** avval brauzerda yuklab olasiz, tekshirishni **terminalda** (qora oyna) qilasiz.

1. `nodejs.org` ga kiring.
2. **LTS** deb yozilgan katta yashil tugmani bosib yuklang.
3. Faylni oching. **Next** bosib boraveng. Oxirida **Install**.
4. Tekshiring: yangi terminal oching va yozing: `node -v`. Raqam chiqsa (masalan `v22.1.0`), tayyor.

### 3.3. Python

📍 **Qayerda:** brauzerda yuklab olasiz, o'rnatuvchi oynasi ochiladi, tekshirish va `pip` buyrug'i **terminalda**.

1. `python.org/downloads` ga kiring va **Download Python** ni bosing.
2. Faylni oching. **Eng muhim joy:** pastdagi **"Add python.exe to PATH"** katakchasini **belgilang**. Keyin **Install Now**.
3. Tekshiring: yangi terminalda `python --version` yozing. Raqam chiqsa, tayyor.
4. Keyin shuni yozing (ikkita kichik kutubxona o'rnatadi):
   `pip install numpy scipy`

![Python o'rnatish](rasm/04-python-path.png)


### 3.4. ffmpeg

📍 **Qayerda:** **terminalda** (qora oyna).
Terminalda shuni yozing va Enter bosing:
`winget install Gyan.FFmpeg`
Savol so'rasa `Y` yozing. Tugagach **terminalni yopib, yangisini oching** va tekshiring: `ffmpeg -version`. Matn chiqsa, tayyor.

(Agar `winget` ishlamasa: Claude Code o'rnatilgach, unga "kompyuterimga ffmpeg o'rnatib ber" deng.)

### 3.5. Claude Code

📍 **Qayerda:** **terminalda** (qora oyna). `claude` yozgach xuddi shu oynada Claude ochiladi.

1. Terminalda shuni yozing:
   `npm install -g @anthropic-ai/claude-code`

2. Tugagach yozing: `claude`
3. Brauzer ochiladi, Claude hisobingizga kiring va ruxsat bering.
4. Terminalda Claude javob bersa, tayyor. Chiqish uchun `/exit` yozing.

(O'rnatish usuli o'zgargan bo'lsa, rasmiy sahifaga qarang: `docs.claude.com`, "Claude Code" bo'limi.)

![Tekshiruv](rasm/05-tekshiruv.png)


---

## 4. O'rnatish: Mac

📍 **Qayerda:** hammasi **Terminal** dasturida.

**Terminal nima?** Dasturlar ichidan **Terminal** ni toping (Spotlight: Cmd+Space, "Terminal" deb yozing).

1. **Homebrew** (dastur o'rnatuvchi): `brew.sh` saytidagi bitta uzun buyruqni nusxalab terminalga qo'ying va Enter bosing. Parolingizni so'rasa, kompyuter parolini yozing (yozganda ko'rinmaydi, bu normal).
2. Keyin shu uchta buyruqni birin-ketin yozing:
   - `brew install node`
   - `brew install python`
   - `brew install ffmpeg`
3. Kutubxonalar: `pip3 install numpy scipy`
4. Claude Code: `npm install -g @anthropic-ai/claude-code`, keyin `claude` yozib hisobingizga kiring.
5. Tekshiring: `node -v`, `python3 --version`, `ffmpeg -version`. Hammasi raqam/matn chiqarsa, tayyor.

---

## 5. Paketni joyiga qo'yish

📍 **Qayerda:** **papka oynasi** (Windows: Explorer, Mac: Finder). Terminal kerak emas.

Siz yuklab olgan zip fayl ichida `reels-rejissyor-pro` papkasi bor.

1. Zip'ni oching (o'ng tugma, "Extract All" yoki Mac'da ikki marta bosing).
2. Claude Code skill papkasini toping:
   - **Windows:** `C:\Users\SIZNING_ISMINGIZ\.claude\skills\`
   - **Mac:** `~/.claude/skills/` (Finder'da Cmd+Shift+. bosing, yashirin papkalar ko'rinadi)
3. `reels-rejissyor-pro` papkasini shu `skills` papkasi ichiga tashlang. Natija shunday bo'lishi kerak:
   `.claude/skills/reels-rejissyor-pro/SKILL.md`

![Papkalar tuzilishi](rasm/02-papkalar.png)


**`.claude` yoki `skills` papkasi yo'qmi?** Avval Claude Code'ni bir marta ishga tushiring (`claude`), `.claude` papkasi paydo bo'ladi. `skills` papkasini o'zingiz yarating (yangi papka, nomi `skills`).

---

## 6. Tekshiruv: hammasi ishlayaptimi?

📍 **Qayerda:** avval papka oynasi, keyin terminal, keyin **Claude ichida** (2-oyna).

1. Kompyuterda yangi papka yarating, masalan `Hujjatlar` ichida `reels`.
2. Shu papkani terminalda oching:
   - **Windows:** papkani oching, tepadagi manzil qatoriga bosing, `cmd` deb yozing va Enter bosing.
   - **Mac:** papkaga o'ng tugma bosing, "Terminal'da yangi oyna" ni tanlang.

![Terminalni ochish](rasm/03-terminal-ochish.png)

3. Yozing: `claude`
4. Claude'ga shuni yozing:

   `reels-rejissyor-pro skilli o'rnatilganini tekshir. Node, Python, ffmpeg o'rnatilganmi, shuni ham tekshir va yetishmaganini o'zing o'rnat.`

Claude hamma narsani tekshiradi va yetishmaganini o'zi o'rnatadi. Hammasi "tayyor" desa, 7-bo'limga o'ting.

---

## 7. Birinchi videoni yasash

📍 **Qayerda:** asosan **Claude ichida** (2-oyna). Ovoz faylini **papka oynasiga** (3-oyna) tashlaysiz.

Hammasini Claude Code ichida, `reels` papkasida bajarasiz.

### Qadam 1. Mavzuni ayting

📍 **Qayerda:** Claude ichida.
Claude'ga yozing (mavzuni o'zingiznikiga almashtiring):

`reels-rejissyor-pro bilan "Excel'da pul tejash" mavzusida reels qil. Bu video ish qidirayotgan yoshlar uchun.`

Claude sizga 3 xil hook (birinchi gap) va tanlangan ssenariy beradi. Yoqmasa: "boshqacha hook yoz" deng.

![Claude bilan suhbat](rasm/06-claude-suhbat.png)


### Qadam 2. Ovoz matnini oling

📍 **Qayerda:** Claude ichida, javobdagi matnni nusxalaysiz.
Claude "OVOZ MATNI" beradi. Bu bitta uzun paragraf. Uni nusxalang.

### Qadam 3. Ovozni yarating (ikki yo'l)

📍 **Qayerda:** telefonda yoki brauzerda (elevenlabs.io). Tayyor faylni **papka oynasiga** tashlaysiz.

**A yo'li: o'z ovozingiz (bepul).** Telefonda ovoz yozish dasturini oching, matnni tinch xonada, o'rtacha tezlikda o'qing. Faylni kompyuterga `reels` papkasiga tashlang, nomi `ovoz.mp3` (yoki `.m4a`, `.wav`) bo'lsin.

**B yo'li: ElevenLabs.**

1. `elevenlabs.io` ga kiring, hisob oching.
2. **Text to Speech** bo'limiga kiring.
3. Modelni **Eleven v3** qiling (o'zbekcha uchun eng yaxshisi) va ovozni tanlang.
4. Matnni qo'ying, **Generate** bosing.
5. Eshitib ko'ring: talaffuz noto'g'ri bo'lsa, o'sha so'zni matnda o'zgartirib qayta yarating.
6. Yuklab oling va `reels` papkasiga `ovoz.mp3` qilib tashlang.

![ElevenLabs](rasm/07-elevenlabs.png)


### Qadam 4. Videoni yig'ishni boshlang

📍 **Qayerda:** Claude ichida.
Claude'ga yozing:

`Mana ovoz: ovoz.mp3. Videoni yig'. Papka nomi: birinchi-video.`

Claude shularni o'zi qiladi: shablonni nusxalaydi, ovozni tozalaydi, har gapni ovozdan topadi, sahnalarni yozadi, tovushlarni qo'yadi, avval bir nechta rasm (kadr) ko'rsatib tekshiradi.

### Qadam 5. Rasmlarni ko'ring

📍 **Qayerda:** Claude ichida (rasmlarni papka oynasida ham ochib ko'rishingiz mumkin: `birinchi-video/out`).
Claude bir nechta kadrni ko'rsatadi. Tekshiring: yozuvlar o'qiladimi? Bir-birining ustiga tushmaganmi? Xato topsangiz oddiy tilda ayting: "uchinchi kadrdagi yozuv juda kichik, kattalashtir".

### Qadam 6. Render (tayyor video)

📍 **Qayerda:** Claude ichida. Natija **papka oynasida**: `birinchi-video/out/final.mp4`.
Claude renderni ishga tushiradi. 40-50 soniyalik video uchun 4-8 daqiqa ketadi (kompyuteringizga qarab). Kutib turing, terminalni yopmang. "TAYYOR" deb yozilgach, video `birinchi-video/out/final.mp4` da bo'ladi.

### Qadam 7. Muqova va caption

📍 **Qayerda:** Claude ichida.
Claude'ga yozing: `Muqova rasmini ham qil, caption va hashtag yoz.`

Hammasi shu. Videoni Instagram'ga o'zingiz joylaysiz. Eng yaxshi vaqt: kechqurun 20:00 atrofi.

![Natija](rasm/08-natija.png)


---

## 8. Video ichini o'zgartirish

📍 **Qayerda:** Claude ichida.

Hamma o'zgarishni oddiy tilda Claude'ga ayting. Misollar:

- "Personaj yuzini ko'rsat" (u personaj varaqasi rasmini ko'rsatadi, siz tasdiqlaysiz).
- "Hook so'zini 'Prompti qanaqa?' emas, shunday qil: ..."
- "3-sahnadagi karta o'rniga raqamlar sanalib chiqsin."
- "Oxirgi kartadagi yozuvni o'zgartir."
- "Fon musiqasi sal past bo'lsin."
- "Muhim so'z (masalan 'BEPUL') katta bo'lib urilib tushsin."

O'zgarishdan keyin Claude qayta rasm ko'rsatadi, siz tasdiqlasangiz qayta render qiladi.

**Maslahat:** kichik o'zgarish uchun to'liq qayta render shart emas. Claude'ga "faqat 3-sahnani qayta ko'rsat" deng, u bitta kadrni ko'rsatadi.

---

## 9. Xatolar va ularning yechimi

| Nima bo'ldi | Nima qilish kerak |
|---|---|
| `node` yoki `python` "topilmadi" yozadi | Yangi terminal oching. Hali ham chiqsa, o'rnatishni qayta bajaring (Python'da "Add to PATH" belgilanganmi?). |
| `npm install` xato beradi | Xatoni nusxalab Claude'ga yozing. Internet borligini tekshiring. |
| Render juda sekin | Kompyuter kuchsiz. Boshqa dasturlarni yoping. 8 daqiqadan 15 daqiqagacha bo'lishi mumkin, bu normal. |
| Render o'rtada to'xtadi | Shu buyruqni qayta ishga tushiring. Tayyor bo'laklar qayta render bo'lmaydi, davom etadi. |
| Subtitr ovozdan oldin/keyin yonyapti | Claude'ga: "subtitr vaqtini ovozga qayta moslashtir". U gap chegaralarini aniq beradi. |
| Personaj og'zi harakatlanmayapti | Ovoz fayli to'g'ri joyda emas yoki juda past. Claude'ga: "lip-sync ni qayta hisobla". |
| Talaffuz noto'g'ri (ovozda) | ElevenLabs'da matnni o'zbekcha o'qilishicha yozing: `Claude` o'rniga `Klod`. |
| Windows'da `render.sh` ishlamadi | Git for Windows o'rnatilganini tekshiring (3.1). Claude'ga: "render buyrug'ini Windows'da ishga tushir". |
| Claude skillni "ko'rmayapti" | Papka yo'li to'g'rimi? `.claude/skills/reels-rejissyor-pro/SKILL.md` bo'lishi kerak. Claude Code'ni yopib qayta oching. |
| Hech nima tushunarsiz | Telegram: @mmn0300. Xato matnini yoki skrinshotni yuboring. |

---

## 10. Havolalar ro'yxati

| Nima | Manzil |
|---|---|
| Claude (hisob ochish) | claude.ai |
| Claude Code qo'llanmasi | docs.claude.com |
| Node.js (LTS) | nodejs.org |
| Python | python.org/downloads |
| Git for Windows | git-scm.com/download/win |
| ffmpeg (Windows: `winget install Gyan.FFmpeg`, Mac: `brew install ffmpeg`) | ffmpeg.org |
| Homebrew (Mac) | brew.sh |
| ElevenLabs (ovoz) | elevenlabs.io |
| Remotion (video dasturi, hujjat) | remotion.dev |

---

## Foydalanish shartlari

- Paketni o'zingiz va o'z biznesingiz uchun ishlating. Qayta sotish va tarqatish mumkin emas.
- Remotion: yakka shaxs va 3 kishigacha bo'lgan kompaniyalar uchun bepul. Kattaroq kompaniya remotion.dev dan litsenziya oladi.

Savol: Telegram @mmn0300 · Kanal: @mashrabbekmaxmatkulov
