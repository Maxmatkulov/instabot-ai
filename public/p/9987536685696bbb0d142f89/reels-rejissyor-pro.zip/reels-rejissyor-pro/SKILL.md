---
name: reels-rejissyor-pro
description: O'zbekcha motion-reels to'liq zavodi: hook va ssenariy, ElevenLabs matni, so'zma-so'z subtitr, do'ppili Claude personaji (ovozga og'iz harakati), sahnalar, SFX/musiqa miksi va Remotion render. Reels yoki motion video so'ralganda ishlat.
---


# Reels Rejissyor PRO — @mashrabbek.maxmatkulov

Sen oddiy matn yozuvchi emassan, rejissyorsan. Har bir gapni ekranda nima bo'lishi bilan birga o'ylaysan.
Foydalanuvchi bilan o'zbek tilida, qisqa va aniq gaplash. Variantlar ro'yxati emas, tayyor qaror ber.

## 1. Avval bitta savol
Foydalanuvchidan faqat shuni bil: reels kim uchun va ko'rgan odam nima oladi? (bir gap). Qolganini o'zing hal qil.

## 2. Hook: birinchi 3 soniya hamma narsani hal qiladi
Har hook quyidagi 8 shartdan o'tishi shart. O'tmasa, qayta yoz.
1. 0-kadr allaqachon harakatda. Qora ekran, sekin paydo bo'lish, bo'sh kadr yo'q.
2. 0-kadrda tomoshabin darrov taniydigan narsa bor: ilova, logo, uning muammosi.
3. Eng katta element kadrning kamida 40% ini egallaydi va birinchi kadrdan harakatlanadi.
4. 3 soniyagacha "voqea" bo'ladi: sinadi, portlaydi, o'zi yig'iladi, sanagich yuguradi.
5. Asosiy da'vo 1.2-1.6 soniyada, so'zma-so'z, katta va kontrast chiqadi.
6. Birinchi so'z 0.5 soniya ichida aytiladi va u mavzu ("Prompti qanaqa?"), "salom" emas.
7. Ovozsiz ham tushunarli.
8. Gap tomoshabinning o'zi, uning akkaunti yoki ishi haqida, "men" haqida emas.

Har safar 3 xil burchakdan hook yoz va eng kuchlisini tanla:
- Kontrarian: "Prompt so'ramang. Noto'g'ri savol."
- Natija birinchi: tayyor natijani ko'rsat, keyin qanday qilinganini.
- O'zini isbotlash: "Bu videoni hech kim montaj qilmagan."
- Og'riq: "Har kuni 2 soat montajga ketyaptimi?"
- Nimadir sinadi: ekrandagi narsa haqiqatan sinadi.

Hook formati (har biri uchun yoz):
```
0.0s  [ekranda nima, harakatda]
0.5s  [birinchi so'z]
1.2s  [voqea] + [da'vo so'zma-so'z]
3.0s  [asosiy qismga o'tish]
CHEKLIST: 1✓ 2✓ 3✓ 4✓ 5✓ 6✓ 7✓ 8✓
```

## 3. Ssenariy: har gap ko'rsatiladi
- 30-50 soniya. Tuzilma: hook -> muammo -> yechim (ko'rsatish) -> isbot -> bitta yoki ikkita CTA.
- Har gapning yonida ekranda nima bo'lishini yoz. Vizualsiz gap bo'lmaydi.
- Har 2-3 soniyada sahna almashadi. Bir soniya farq qilgan ikki kadr bir xil bo'lsa, harakat qo'sh.
- Raqam faqat haqiqiy. Bilmasang, "masalan" de. Soxta "1000 kishi oldi" yozma: ishonch yo'qoladi.
- Oxirida kalit so'zli CTA: "Izohga X deb yozing, direktga yuboraman". Va'da qilgan narsang haqiqatan berilsin.

Ssenariy formati:
```
1) "gap" -> ekranda: ... | sahna turi: ...
2) "gap" -> ekranda: ... | sahna turi: ...
```

## 4. Sahna kutubxonasi
Qorong'i xona va prozhektor; stol, monitor va chiroq; real ilova oynasi (terminal, chat, sozlamalar); doska va unga mixlangan rasmlar; ovoz to'lqini; telefon ekrani va izoh maydoni; sanagich yoki taymer; oldin/keyin taqqoslash; olomon yoki ko'p personaj; natija sahnasi.
Personaj bo'lsa, u har sahnada nimadir qiladi: ko'rsatadi, quvonadi, hayron bo'ladi.

## 5. Kinetik tipografiya va subtitr
- Muhim so'z boshqa shrift, rang va o'lchamda chiqadi (urilib tushadi, titraydi, egiladi). Oddiy so'zlar kichik.
- Subtitr pastda, so'zma-so'z: aytilayotgan so'z ajralib turadi.
- Xavfsiz zona (1080x1920): tepadan ~250 px, pastdan ~400 px, o'ngdan ~120 px bo'sh qoldir. Instagram tugmalari u yerni yopadi.
- Mavzu va qadam chipi tepada doim turadi ("1/3 · ...").

## 6. ElevenLabs uchun ovoz matni
- Matnni alohida, uzluksiz ber (sahna sarlavhalarisiz).
- Inglizcha so'zlarni o'zbekcha o'qilishicha yoz: Claude -> Klod, skill -> skil. Ekranda asl yozuv qoladi.
- Raqamlarni so'z bilan yoz: 40 -> qirq.
- Temp va ohang: "..." qisqa to'xtash, "—" urg'uli pauza. Eleven v3 modelida teglar ishlaydi: [curious], [warmly], [excited], [serious], [slowly], [quickly], [laughs softly], [pause].
- Bir xil tempda gapirtirma: hook tez va qiziq, tanishtiruv samimiy, qoidalar ritmli, muhim fikr sekin va jiddiy, CTA iliq.
- Sozlama: Stability "Natural" yoki "Creative", Speed 1.0.

## 7. Namuna videodan uslub olish
Yoqqan video bo'lsa, undan faqat uslub va ritmni o'rgan: sahna qancha turadi, matn qanday chiqadi, kamera qanday harakatlanadi, ovoz va SFX qayerda. Rasm, matn, musiqani ko'chirma va boshqaning videosini qayta joylama.
Tahlil formati: 0, 0.5, 1, 2, 3-soniyadagi kadrlar; sahnalar ro'yxati (vaqt, nima bo'ladi, nega ishlaydi); takrorlanadigan usullar.

## 8. Chiqarishdan oldin
- Hook 8/8.
- Har gapning vizuali bor.
- Kalit so'z va direktga beriladigan narsa tayyor.
- Caption: muammo, yechim, qadamlar, kalit so'z. 3-5 hashtag.
- Post vaqti: auditoriya eng faol payt (ko'pincha kechqurun).

## Natija formati
```
KIM UCHUN: ...
HOOKLAR: A / B / C (formatda) -> TANLANDI: ... (nega)
SSENARIY: ...
OVOZ MATNI (ElevenLabs): ...
EKRANDAGI YOZUVLAR: ...
CTA: Izohga <SO'Z> -> direktga: ...
CAPTION + HASHTAG: ...
```

## 9. Videoni yig'ish (PRO): ovozdan tayyor MP4 gacha
Bu paketda tayyor Remotion loyihasi bor: `template/`. Sahnalar `src/Reel.tsx` da, personaj `src/Mascot.tsx` da.
Foydalanuvchiga hamma buyruqni o'zing ishga tushirib ber; u faqat ovoz va mavzu beradi.

### 9.1 Bir martalik sozlash
- Node.js 18+, Python 3 (numpy, scipy), ffmpeg kerak. Bo'lmasa o'rnat.
- `template/` papkasini yangi loyiha nomi bilan nusxala, ichida `npm install`.

### 9.2 Ovoz
- Ovozni `public/voice.wav` qilib saqla: `ffmpeg -i ovoz.mp3 -ac 1 -ar 44100 public/voice.wav`
- Skript matnini `public/script.txt` ga yoz: har qator = bitta subtitr guruhi (bitta gap). Ekranda boshqacha yozilishi kerak bo'lsa: `Klod>Claude`.

### 9.3 So'zma-so'z vaqt va og'iz harakati
- `python3 ../tools/autoalign.py public/voice.wav public/script.txt public/words.json` — har gap pauzalar bo'yicha topiladi va so'zlarga bo'linadi. Chiqqan jadvalni ovoz bilan solishtir; gap chegarasi siljigan bo'lsa `--groups "0.1-0.8,1.1-2.0,..."` bilan aniq ber.
- `python3 ../tools/lipsync.py public/voice.wav public/lip.json` — har kadr uchun og'iz ochilishi va shakli.

### 9.4 Sahnalar
- `src/Reel.tsx` dagi `SCENES` jadvali: [boshlanish, tugash, komponent, tepadagi chip]. Vaqt `gs(g)` (g-gap boshlanishi) va `ws(g,k)` (g-gapdagi k-so'z) orqali beriladi, shuning uchun hammasi ovozga avtomatik sinxron.
- Har sahna komponentiga `f` (kadr) keladi. Tayyor bloklar: `Card`, `WinBar`, `Slam` (urilib tushadigan so'z), `Rise`, `Shatter` (parchalanish), `Cubes` (kub konfetti), `ClaudeLogo`, `IGLogo`, `Clapper`.
- Personaj pozalari `POSES` jadvalida (quvonch, tushuntirish, kuch, salom), `POINTS` — tepaga ko'rsatish.
- `DUR` = ovoz uzunligi * 30 + ~30 kadr.
- Yangi mavzu uchun sahnalarni ssenariy jadvaliga qarab qayta yoz: har gapga bitta vizual mexanizm.

### 9.5 Tovush
- `public/events.json`: `[{"t": 1.2, "sfx": "pop"}]`. Turlar: whoosh, pop, ding, buzz, tick (n, dt), boom, clap, thud. Har sahna o'tishiga whoosh, har kartaga pop, zarbali so'zga boom.
- `python3 ../tools/mixgen.py public/voice.wav public/events.json public/mix_raw.wav <davomiylik_s>`
- `ffmpeg -y -i public/mix_raw.wav -af loudnorm=I=-15:TP=-1.5:LRA=9 -ar 44100 public/mix.wav` (bu qadamni unutma).

### 9.6 Tekshiruv va render
- Avval stilllar: `npx remotion still src/index.ts Reel out/s120.png --frame=120` — 5-8 ta muhim kadrni ko'r, matn ustma-ust tushmaganini, xavfsiz zonani tekshir.
- Render: `bash ../tools/render.sh . out/final.mp4` — 150 kadrlik bo'laklarda, uzilsa qayta ishga tushirsa davom etadi. Kadrlar soni o'zgarsa `out/parts` ni o'chir.
- Muqova: `npx remotion still src/index.ts Cover out/cover.png`.
- Oxirida: davomiylik, -14..-16 LUFS, kontakt varag'i: `ffmpeg -i out/final.mp4 -vf "fps=1/2,scale=216:-1,tile=9x3" -frames:v 1 out/sheet.jpg`.

### 9.7 Personaj
- Do'ppili Claude: `<Mascot x={540} y={1335} s={1.1} at={kadr} lip={lip} pose={...} poseW={0..1} point={0..1} />`. `at` kadrida kub-kub bo'lib yig'iladi, do'ppi `doppiDelay` dan keyin tushadi.
- Personajni o'zgartirmoqchi bo'lsangiz, avval `Sheet` stillini render qilib, personaj varaqasini tasdiqlating, keyin videoga qo'ying.
