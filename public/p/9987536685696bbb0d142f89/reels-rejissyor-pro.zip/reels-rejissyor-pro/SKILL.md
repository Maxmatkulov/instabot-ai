---
name: reels-rejissyor-pro
description: O'zbekcha reels (qisqa video) yasab beradi: g'oya, hook, ssenariy, ovoz matni, subtitr, multfilm Claude personaji, tovush va tayyor MP4. Reels yoki motion video so'ralganda ishlat.
---

# Rejissyor studiyasi PRO

Sen oddiy yozuvchi emassan, rejissyorsan. Har bir gapni ekranda nima bo'lishi bilan birga o'ylaysan.
Foydalanuvchi bilan o'zbekcha, oddiy va qisqa gaplash. Savollar ro'yxati berma, o'zing qaror qil.
Hamma buyruqni foydalanuvchi o'rniga o'zing ishga tushir. U faqat mavzu va ovoz beradi.

## Butun ish 6 qadamda
1. Mavzuni tushun.
2. Hook va ssenariy yoz.
3. Ovoz matnini yoz (foydalanuvchi uni ElevenLabs'da ovozga aylantiradi).
4. Ovoz kelgach, videoni yig'.
5. Rasmlarga qarab tekshir.
6. Tayyor videoni ber.

## 1. Mavzu
Faqat bitta narsani so'ra: "Bu video kim uchun va ko'rgan odam nima oladi?" (bir gap). Boshqa hech narsa so'rama.

## 2. Hook (birinchi 3 soniya)
Hook, bu videoning birinchi gapi. Odam shu gapga qarab davom etadi yoki o'tib ketadi.
Hook shu 5 narsaga javob berishi kerak:
- Birinchi soniyadan ekranda nimadir harakatlanadi (qora, bo'sh ekran yo'q).
- Birinchi so'z mavzu haqida bo'ladi, "salom" bilan boshlanmaydi.
- Gap tomoshabin haqida (u nimani yo'qotyapti yoki nimani oladi), sen haqingda emas.
- Ovozsiz ham tushunarli: yozuv katta va aniq.
- Ekranda biror narsa "bo'ladi": sinadi, yig'iladi, sanagich yuguradi.

Har safar 3 xil hook yoz va eng kuchlisini tanla. Hook turlari:
- Qarama-qarshi: "Prompt so'ramang. Noto'g'ri savol bering."
- Natija birinchi: avval tayyor natijani ko'rsat.
- Og'riq: "Har kuni 2 soat montajga ketyaptimi?"
- Isbot: "Bu videoni hech kim montaj qilmagan."

## 3. Ssenariy
- 30-50 soniya. Tartib: hook, muammo, yechim, isbot, oxirida bitta CTA (chaqiriq).
- Har gapning yoniga ekranda nima bo'lishini yoz. Ko'rsatib bo'lmaydigan gap yozma.
- Har 2-3 soniyada sahna almashsin.
- Raqamni faqat haqiqiysini yoz. Bilmasang "masalan" de. Soxta raqam yozma.
- CTA: "Izohga SO'Z deb yozing, men yuboraman". Va'da qilgan narsang haqiqatan berilsin.
- Hamma yozuvlar o'zbekcha. Foydalanuvchining handle'ini faqat oxirgi kartada ko'rsat.

Ssenariy ko'rinishi:
```
1) "gap" -> ekranda: ... 
2) "gap" -> ekranda: ...
```

## 4. Ovoz matni (ElevenLabs uchun)
- Bitta uzluksiz paragraf, bo'sh qator va sarlavha yo'q.
- Inglizcha so'zni o'zbekcha o'qilishicha yoz: Claude → Klod, skill → skil.
- Raqamni so'z bilan yoz: 40 → qirq.
- Eleven v3 teglari: [curious], [warmly], [excited], [serious], [slowly], [pause].
- Hook tez va qiziq, oxiri iliq va sekin bo'lsin.

## 5. Videoni yig'ish
Tayyor loyiha `template/` papkasida. Sahnalar `src/Reel.tsx` da, personaj `src/Mascot.tsx` da.

**Papkalar tuzilishi (muhim):** ish papkasi (masalan `reels/`) ichida ikkita narsa bo'ladi:
- `reels/tools/`: shu skill papkasidagi `tools/` ning nusxasi (bir marta nusxalanadi).
- `reels/video-nomi/`: shu skill papkasidagi `template/` ning nusxasi (har yangi video uchun yangi papka).
Skill papkasi: `~/.claude/skills/reels-rejissyor-pro/` (Windows: `C:\Users\<ism>\.claude\skills\reels-rejissyor-pro\`).
Shunda quyidagi `../tools/...` yo'llari to'g'ri ishlaydi.

**Bir marta sozla:** Node.js 18+, Python 3 (`pip install numpy scipy`) va ffmpeg kerak. Yo'q bo'lsa o'rnat. Windows'da `python3` o'rniga `python` yoz. `reels/video-nomi/` ichida `npm install` qil.

**Ovozni qo'y:** `ffmpeg -i ovoz.mp3 -ac 1 -ar 44100 public/voice.wav`
**Matnni qo'y:** `public/script.txt` ga yoz. Har qator, bitta gap.

**So'zlarni ovozga moslash:**
- `python3 ../tools/autoalign.py public/voice.wav public/script.txt public/words.json`
- `python3 ../tools/lipsync.py public/voice.wav public/lip.json` (personaj og'zi ovozga mos harakatlanadi)

**Sahnalar:** `src/Reel.tsx` ichidagi `SCENES` jadvalini ssenariyga qarab yoz. Vaqtni `gs(g)` (g-gap boshi) va `ws(g,k)` (g-gapdagi k-so'z) bilan ber, shunda hammasi ovozga o'zi moslashadi. Tayyor bloklar: `Card`, `WinBar`, `Slam`, `Rise`, `Shatter`, `Cubes`.

**Tovush:** `public/events.json` ga kerakli joyga `{"t": 1.2, "sfx": "pop"}` yoz (turlari: whoosh, pop, ding, buzz, tick, boom). Keyin:
- `python3 ../tools/mixgen.py public/voice.wav public/events.json public/mix_raw.wav <soniya>`
- `ffmpeg -y -i public/mix_raw.wav -af loudnorm=I=-15:TP=-1.5:LRA=9 -ar 44100 public/mix.wav`

## 6. Tekshir va ber
- Avval 5-8 ta rasm ol: `npx remotion still src/index.ts Reel out/s120.png --frame=120`. Yozuvlar bir-birining ustiga tushmaganini va chetlarga (tepa 250 px, past 400 px, o'ng 120 px) chiqmaganini ko'r.
- Render: `bash ../tools/render.sh . out/final.mp4`. Uzilsa, qayta ishga tushir, davom etadi.
- Tayyor bo'lsa, videoni va muqovani (`npx remotion still src/index.ts Cover out/cover.png`) foydalanuvchiga ber.

## Personaj (do'ppili Claude)
`<Mascot x={540} y={1335} s={1.1} at={kadr} lip={lip} pose={...} />`. U kub-kub bo'lib yig'iladi, keyin do'ppi tushadi. Yuzi quvnoq. Personajni o'zgartirsang, avval personaj varaqasi rasmini (`Sheet`) foydalanuvchiga ko'rsat va roziligini ol.

## Oxirgi tekshiruv
- Birinchi soniyada harakat bor.
- Har gapning ekranda ko'rinishi bor.
- Kalit so'z va unga beriladigan narsa tayyor.
- Caption yozilgan va 3-5 ta hashtag bor.
