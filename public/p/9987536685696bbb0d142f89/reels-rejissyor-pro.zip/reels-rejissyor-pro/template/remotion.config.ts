import {Config} from '@remotion/cli/config';
// 'angle' GPU'siz kompyuterda ham tez ishlaydi. 'swangle' ishlatmang: soya/blur filtrlari 5 baravar sekinlashadi.
Config.setChromiumOpenGlRenderer('angle');
Config.setVideoImageFormat('jpeg');
