// @ts-nocheck
import React from 'react';
import {useCurrentFrame, spring} from 'remotion';
// Claude mascot v2: kub-kub (voxel) tana, Chust do'ppisi, ovozga qarab og'iz harakati.
// <Mascot x={540} y={1400} s={1} lip={lipArray} at={0} face="smile" />
// lip = lipsync.py chiqargan [[a,c],...] (30 fps). Berilmasa face ishlatiladi.
export const SKIN = '#D2694A', SKIN_L = '#E58260', SKIN_D = '#A8503A';
const FPS = 30, CELL = 38;
const Box: React.FC<any> = ({w, h, d, color = SKIN, style, children}) => {
  const grid = `linear-gradient(rgba(60,20,10,.22) 2px, transparent 2px), linear-gradient(90deg, rgba(60,20,10,.22) 2px, transparent 2px)`;
  const face = (tf: string, c: string, W: number, H: number, kids?: any) => (
    <div style={{position: 'absolute', left: '50%', top: '50%', width: W, height: H, marginLeft: -W / 2, marginTop: -H / 2, background: c, transform: tf, backfaceVisibility: 'hidden',
      backgroundImage: grid, backgroundSize: `${CELL}px ${CELL}px`, boxShadow: 'inset 0 0 0 3px rgba(60,20,10,.28)'}}>{kids}</div>
  );
  return (
    <div style={{position: 'absolute', width: w, height: h, transformStyle: 'preserve-3d', ...style}}>
      {face(`translateZ(${d / 2}px)`, color, w, h, children)}
      {face(`rotateY(180deg) translateZ(${d / 2}px)`, SKIN_D, w, h)}
      {face(`rotateY(90deg) translateZ(${w / 2}px)`, '#BC5B40', d, h)}
      {face(`rotateY(-90deg) translateZ(${w / 2}px)`, '#BC5B40', d, h)}
      {face(`rotateX(90deg) translateZ(${h / 2}px)`, SKIN_L, w, d)}
      {face(`rotateX(-90deg) translateZ(${h / 2}px)`, SKIN_D, w, d)}
    </div>
  );
};
// ---------- Chust do'ppisi (rasm bo'yicha: qora, oq bodom (paisley) va kalit-naqsh kamar) ----------
const W = '#fff', K = '#0B0B0F';
const Paisley: React.FC<any> = ({x, y, s = 1, r = 0, flip = 1}) => {
  const body = 'M0 -46 C-46 -46 -62 14 -22 40 C 20 66 78 44 128 -6 C 150 -28 170 -34 176 -42 C 120 -62 70 -34 40 -42 C 24 -46 12 -46 0 -46Z';
  return (
    <g transform={`translate(${x} ${y}) rotate(${r}) scale(${s * flip} ${s})`}>
      <path d={body} fill={K} stroke={W} strokeWidth="7" strokeLinejoin="round" />
      <path d={body} fill="none" stroke={W} strokeWidth="5" transform="translate(-2 0) scale(.86) translate(6 4)" />
      {[0.66, 0.44].map((k, i) => <circle key={i} cx="-4" cy="-2" r={34 * k + 4} fill="none" stroke={W} strokeWidth="5" />)}
      <circle cx="-4" cy="-2" r="7" fill={W} />
    </g>
  );
};
const Star: React.FC<any> = ({x, y}) => (
  <g transform={`translate(${x} ${y})`} fill={W}>{[0, 60, 120].map((a) => <rect key={a} x="-1.5" y="-9" width="3" height="18" transform={`rotate(${a})`} />)}<circle r="2.6" /></g>
);
const Dot: React.FC<any> = ({x, y, r = 5}) => <g><circle cx={x} cy={y} r={r} fill={W} /><circle cx={x} cy={y} r={r - 2.4} fill={K} /><circle cx={x} cy={y} r={1.6} fill={W} /></g>;
// kalit-naqsh (meander) kamar
const Band: React.FC<any> = ({w, h}) => {
  const n = 5, u = w / n;
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`}>
      <rect width={w} height={h} fill={K} />
      <rect y="2" width={w} height="4" fill={W} /><rect y="9" width={w} height="2" fill={W} opacity=".85" />
      <rect y={h - 6} width={w} height="4" fill={W} /><rect y={h - 11} width={w} height="2" fill={W} opacity=".85" />
      {Array.from({length: n}).map((_, i) => {
        const x0 = i * u + 6, ww = u - 12;
        return (
          <g key={i} fill="none" stroke={W} strokeWidth="2.6">
            <rect x={x0} y="15" width={ww} height={h - 30} />
            <path d={`M${x0 + 8} ${h / 2 - 5} H${x0 + ww - 8} M${x0 + 8} ${h / 2 + 5} H${x0 + ww - 8}`} />
            <circle cx={x0 + ww / 2} cy={h / 2} r="3.6" fill={W} stroke="none" />
          </g>
        );
      })}
    </svg>
  );
};
const Side: React.FC<any> = ({w, h, k}) => (
  <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`}>
    <rect width={w} height={h} fill={K} />
    <Paisley x={w * 0.30} y={h * 0.62} s={0.62} r={-18} />
    <Paisley x={w * 0.80} y={h * 0.30} s={0.5} r={150} flip={-1} />
    <Star x={w * 0.62} y={h * 0.78} /><Star x={w * 0.9} y={h * 0.7} />
    <Dot x={w * 0.5} y={h * 0.2} /><Dot x={w * 0.1} y={h * 0.25} r={4} /><Dot x={w * 0.66} y={h * 0.5} r={4} />
  </svg>
);
const Doppi: React.FC<any> = () => {
  const bot = 290, top = 214, H = 98, BH = 44;
  const B = bot / 2, T = top / 2;
  const L = Math.sqrt(H * H + (B - T) * (B - T));
  const a = (Math.atan2(B - T, H) * 180) / Math.PI;
  const inset = ((B - T) / bot) * 100;
  const side = (rot: number) => (
    <div style={{position: 'absolute', left: -bot / 2, top: -L / 2, width: bot, height: L, transform: `rotateY(${rot}deg) translateZ(${(B + T) / 2}px) rotateX(${a}deg)`, clipPath: `polygon(${inset}% 0, ${100 - inset}% 0, 100% 100%, 0 100%)`}}>
      <Side w={bot} h={L} />
    </div>
  );
  const band = (rot: number) => (
    <div style={{position: 'absolute', left: -bot / 2, top: -BH / 2, width: bot, height: BH, transform: `rotateY(${rot}deg) translateZ(${B}px)`, backfaceVisibility: 'hidden'}}>
      <Band w={bot} h={BH} />
    </div>
  );
  return (
    <div style={{position: 'absolute', left: 0, top: 0, width: 0, height: 0, transformStyle: 'preserve-3d'}}>
      <div style={{position: 'absolute', left: 0, top: -BH / 2 + 4, width: 0, height: 0, transformStyle: 'preserve-3d'}}>
        {[0, 90, 180, 270].map((r) => <React.Fragment key={r}>{band(r)}</React.Fragment>)}
      </div>
      <div style={{position: 'absolute', left: 0, top: -BH + 4 - H / 2, width: 0, height: 0, transformStyle: 'preserve-3d'}}>
        {[0, 90, 180, 270].map((r) => <React.Fragment key={r}>{side(r)}</React.Fragment>)}
        <div style={{position: 'absolute', left: -top / 2, top: -top / 2, width: top, height: top, background: K, boxShadow: 'inset 0 0 0 5px #fff', transform: `translateY(${-H / 2}px) rotateX(90deg)`}} />
      </div>
    </div>
  );
};
// ---------- yuz ----------
const Face: React.FC<any> = ({kind = 'smile', blink, a = 0, c = 0.5, lipOn}) => {
  const eyeH = blink ? 6 : 46 - a * 8;
  const eye = (x: number) => <div style={{position: 'absolute', left: x, top: 70 + (blink ? 22 : a * 3), width: 28, height: eyeH, background: '#14100E'}} />;
  let mouth;
  if (lipOn) {
    const mw = 46 + c * 40 - a * 6, mh = 8 + a * (60 - c * 18);
    mouth = (
      <div style={{position: 'absolute', left: 150 - mw / 2, top: 142, width: mw, height: mh, background: '#1B0F0C', overflow: 'hidden'}}>
        {mh > 22 && <div style={{position: 'absolute', left: 4, right: 4, top: 0, height: 11, background: '#fff'}} />}
        {mh > 36 && <div style={{position: 'absolute', left: '18%', right: '18%', bottom: 0, height: Math.min(16, mh - 30), background: '#E5736B'}} />}
      </div>
    );
  } else {
    const m: any = {
      smile: <><div style={{position: 'absolute', left: 126, top: 150, width: 48, height: 10, background: '#14100E'}} /><div style={{position: 'absolute', left: 114, top: 140, width: 12, height: 10, background: '#14100E'}} /><div style={{position: 'absolute', left: 174, top: 140, width: 12, height: 10, background: '#14100E'}} /></>,
      flat: <div style={{position: 'absolute', left: 120, top: 150, width: 60, height: 10, background: '#14100E'}} />,
      open: <div style={{position: 'absolute', left: 124, top: 142, width: 52, height: 40, background: '#14100E'}} />,
      wow: <div style={{position: 'absolute', left: 134, top: 142, width: 32, height: 32, background: '#14100E'}} />,
    };
    mouth = m[kind];
  }
  // hushchaqchaq qosh: ichki uchi yuqoriga, gapirganda ko'tariladi
  const brow = (x: number, sg: number) => <div style={{position: 'absolute', left: x - 6, top: 44 - a * 8, width: 40, height: 10, background: '#14100E', transform: `rotate(${sg * (-7 - a * 5)}deg)`}} />;
  const corners = lipOn ? (() => { const mw = 46 + c * 40 - a * 6; return <><div style={{position: 'absolute', left: 150 - mw / 2 - 12, top: 132, width: 12, height: 10, background: '#14100E'}} /><div style={{position: 'absolute', left: 150 + mw / 2, top: 132, width: 12, height: 10, background: '#14100E'}} /></>; })() : null;
  return <>{brow(86, 1)}{brow(186, -1)}{eye(86)}{eye(186)}{mouth}{corners}</>;
};
// qism yig'ilib kirishi: spring bilan (fromX, fromY) dan joyiga
const useIn = (l: number, delay: number) => {
  const p = spring({frame: l - delay, fps: FPS, config: {damping: 12, stiffness: 140, mass: 0.8}});
  return {p, vis: l >= delay};
};
const Part: React.FC<any> = ({l, delay, fx = 0, fy = -900, children, style}) => {
  const {p, vis} = useIn(l, delay);
  if (!vis) return null;
  return <div style={{position: 'absolute', left: 0, top: 0, transformStyle: 'preserve-3d', transform: `translate(${(1 - p) * fx}px, ${(1 - p) * fy}px)`, ...style}}>{children}</div>;
};
// qo'l: yelka + tirsak + musht. th = yelkadan burilish (gradus), bend = tirsak
const Arm: React.FC<any> = ({side = 1, th = 12, bend = 20, delay, l}) => {
  const {p, vis} = useIn(l, delay);
  if (!vis) return null;
  const x = side < 0 ? -40 : 290;
  return (
    <div style={{position: 'absolute', left: x, top: 46, width: 50, height: 0, transformStyle: 'preserve-3d', transform: `translate(${(1 - p) * side * 520}px, ${(1 - p) * -120}px)`}}>
      <Box w={66} h={66} d={66} style={{left: -8, top: -33}} />
      <div style={{position: 'absolute', left: 0, top: 0, width: 50, height: 0, transformStyle: 'preserve-3d', transformOrigin: '25px 0', transform: `rotateZ(${-side * th}deg)`}}>
        <Box w={50} h={92} d={50} style={{left: 0, top: 0}} />
        <div style={{position: 'absolute', left: 0, top: 86, width: 50, height: 0, transformStyle: 'preserve-3d', transformOrigin: '25px 0', transform: `rotateZ(${side * bend}deg)`}}>
          <Box w={50} h={70} d={50} style={{left: 0, top: 0}} />
          <Box w={64} h={56} d={64} style={{left: -7, top: 64}} />
        </div>
      </div>
    </div>
  );
};
export const Mascot: React.FC<any> = ({x = 540, y = 1400, s = 1, face = 'smile', yaw = 0, doppi = true, at = 0, lip, build = true, point = 0, pose, poseW = 1, doppiDelay = 13, shadow = 'rgba(80,40,20,.28)'}) => {
  const f = useCurrentFrame();
  const l = f - at;
  if (l < 0) return null;
  const e = lip && lip[Math.min(f, lip.length - 1)];
  const lipOn = !!lip && l > 14;
  const a = lipOn && e ? e[0] : 0, c = lipOn && e ? e[1] : 0.5;
  // oldingi 3 kadrdan silliqlash (gap vaqtida tebranish)
  const ap = lipOn ? [1, 2, 3].map((k) => (lip[Math.max(0, f - k)] || [0])[0]) : [0, 0, 0];
  const energy = lipOn ? (a * 0.5 + ap[0] * 0.3 + ap[1] * 0.2) : 0;
  const A = (k: number) => (lipOn ? (lip[Math.max(0, f - k)] || [0])[0] : 0);
  const eL = (A(0) + A(1) + A(2) + A(3)) / 4, eR = (A(4) + A(5) + A(6) + A(7)) / 4;
  const idle = 5 + Math.sin(l / 17) * 2;
  const thL = idle + eL * 95, thR = idle + eR * 80;
  const thR2 = thR * (1 - point) + (150 + Math.sin(l / 6) * 6) * point;
  let bdL = 8 + eL * 40, bdR = (8 + eR * 40) * (1 - point) + 2 * point;
  let thL2 = thL, thR3 = thR2;
  if (pose) { const w = poseW, m = (a, b) => a + (b - a) * w; thL2 = m(thL2, pose.thL); thR3 = m(thR3, pose.thR); bdL = m(bdL, pose.bdL); bdR = m(bdR, pose.bdR); }
  const bob = Math.sin(l / 14) * 4 - energy * 7;
  const sq = 1 - 0.035 * Math.sin(l / 14) - energy * 0.05;
  const blink = l % 100 > 94;
  const sway = Math.sin(l / 38) * 7 + yaw + (c - 0.5) * 5 * (lipOn ? 1 : 0);
  const nod = -14 + energy * -5;
  const K = 0.4;
  const lt = (i: number) => (build ? Math.round((2 + i * 3) * K) : -99);
  return (
    <div style={{position: 'absolute', left: x, top: y + bob, width: 0, height: 0, perspective: 1500, transform: `scale(${s})`}}>
      <div style={{position: 'absolute', left: -150, top: -300, width: 300, height: 300, transformStyle: 'preserve-3d', transform: `rotateX(${nod}deg) rotateY(${sway}deg) scaleY(${sq})`}}>
        {[-108, -36, 36, 108].map((lx, i) => (
          <Part key={i} l={l} delay={lt(i)} fy={-(1100 - i * 120)} fx={(i - 1.5) * 60}>
            <Box w={58} h={84} d={58} style={{left: 150 + lx - 29, top: 218}} />
          </Part>
        ))}
        <Part l={l} delay={build ? 6 : -99} fy={-1000}><Box w={300} h={230} d={230} style={{left: 0, top: 0}}><Face kind={face} blink={blink} a={a} c={c} lipOn={lipOn} /></Box></Part>
        <Arm side={-1} l={l} delay={build ? 9 : -99} th={thL2} bend={bdL} />
        <Arm side={1} l={l} delay={build ? 10 : -99} th={thR3} bend={bdR} />
        {doppi && <Part l={l} delay={build ? doppiDelay : -99} fy={-1200}><div style={{position: 'absolute', left: 150, top: 0, width: 0, height: 0, transformStyle: 'preserve-3d'}}><Doppi /></div></Part>}
      </div>
      <div style={{position: 'absolute', left: -190, top: -8, width: 380, height: 40, borderRadius: '50%', background: shadow, filter: 'blur(10px)'}} />
    </div>
  );
};
// qum rangli pol + devor: 2D SVG (3D transform keyingi elementlarni yopib qo'yadi)
export const Sand: React.FC = () => {
  const H = 1180, VP = 540, Wd = 1080, Hh = 1920;
  const hs: number[] = []; let y = H, step = 26;
  while (y < Hh + 40) { hs.push(y); y += step; step *= 1.32; }
  const vs: number[] = []; for (let i = -14; i <= 14; i++) vs.push(i);
  return (
    <svg width={Wd} height={Hh} style={{position: 'absolute', left: 0, top: 0}}>
      <defs><linearGradient id="wall" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#EADBC3" /><stop offset="1" stopColor="#E6D4B8" /></linearGradient></defs>
      <rect width={Wd} height={Hh} fill="url(#wall)" />
      <rect y={H} width={Wd} height={Hh - H} fill="#E2CFAF" />
      <clipPath id="fl"><rect y={H} width={Wd} height={Hh - H} /></clipPath>
      <g stroke="rgba(120,90,50,.16)" strokeWidth="3" clipPath="url(#fl)">
        {hs.map((yy) => <line key={yy} x1="0" x2={Wd} y1={yy} y2={yy} />)}
        {vs.map((i) => <line key={i} x1={VP} y1={H} x2={VP + i * 260} y2={Hh + 20} />)}
      </g>
      <g clipPath="url(#fl)" fill="rgba(140,100,50,.10)">
        {hs.slice(0, -1).map((y0, j) => vs.slice(0, -1).filter((i) => (i + j) % 2 === 0).map((i) => {
          const y1 = hs[j + 1], k0 = (y0 - H) / (Hh + 20 - H), k1 = (y1 - H) / (Hh + 20 - H);
          return <polygon key={j + '_' + i} points={`${VP + i * 260 * k0},${y0} ${VP + (i + 1) * 260 * k0},${y0} ${VP + (i + 1) * 260 * k1},${y1} ${VP + i * 260 * k1},${y1}`} />;
        }))}
      </g>
    </svg>
  );
};
