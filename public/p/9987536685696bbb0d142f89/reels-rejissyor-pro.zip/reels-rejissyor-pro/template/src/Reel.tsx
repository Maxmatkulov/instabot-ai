// @ts-nocheck
import React from 'react';
import {AbsoluteFill, useCurrentFrame, spring, interpolate} from 'remotion';
import {Mascot} from './Mascot';
import lip from '../public/lip.json';
import wordsRaw from '../public/words.json';

export const DUR = 1545;
const FONT = 'Inter, "Helvetica Neue", Arial, sans-serif', MONO = 'ui-monospace, Menlo, Consolas, monospace', SERIF = 'Georgia, "Times New Roman", serif';
const INK = '#120807', LIME = '#B8FF3D', RUST = '#D2694A', RED = '#FF3B3B', CREAM = '#F6EBDD', GOLD = '#FFB347';
const T = (s: number) => Math.round(s * 30);
const words = wordsRaw.map((w) => ({...w, s: w.s * 30, e: w.e * 30}));
const cl = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const pop = (f, at, st = 170, d = 13) => spring({frame: f - at, fps: 30, config: {damping: d, stiffness: st, mass: 0.7}});
const typed = (t, f, at, cps = 30) => t.slice(0, Math.max(0, Math.floor(((f - at) / 30) * cps)));
const win = (f, a, b, fade = 6) => interpolate(f, [a, a + fade, b - fade, b], [0, 1, 1, 0], cl);
const gs = (g) => words.find((w) => w.g === g)?.s ?? 0; // guruh boshlanishi (kadr)
const ws = (g, k) => words.find((w) => w.g === g && w.k === k)?.s ?? 0;

// ───────── xona: to'q qizil studiya, prozhektor, chang zarralari ─────────
const Room = ({f, light}) => {
  const H = 1180, VP = 540, W = 1080, Hh = 1920;
  const hs = []; let y = H, st = 22; while (y < Hh + 40) { hs.push(y); y += st; st *= 1.3; }
  const vs = []; for (let i = -12; i <= 12; i++) vs.push(i);
  return (
    <>
      <svg width={W} height={Hh} style={{position: 'absolute', left: 0, top: 0}}>
        <defs>
          <linearGradient id="wl" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#1B0907" /><stop offset="1" stopColor="#2C0F0B" /></linearGradient>
          <linearGradient id="fl" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#3A140F" /><stop offset="1" stopColor="#160605" /></linearGradient>
          <clipPath id="flc"><rect y={H} width={W} height={Hh - H} /></clipPath>
        </defs>
        <rect width={W} height={Hh} fill="url(#wl)" />
        {Array.from({length: 13}).map((_, i) => <rect key={i} x={i * 90 - 10} y={0} width={4} height={H} fill="rgba(0,0,0,.25)" />)}
        <rect y={H} width={W} height={Hh - H} fill="url(#fl)" />
        <g stroke="rgba(255,140,100,.07)" strokeWidth="2" clipPath="url(#flc)">
          {hs.map((yy) => <line key={yy} x1="0" x2={W} y1={yy} y2={yy} />)}
          {vs.map((i) => <line key={i} x1={VP} y1={H} x2={VP + i * 240} y2={Hh + 20} />)}
        </g>
        <ellipse cx="540" cy="1340" rx={330} ry={70} fill="#7A1414" opacity={0.85} />
        <ellipse cx="540" cy="1340" rx={330} ry={70} fill="none" stroke="#A82222" strokeWidth="6" opacity={0.7} />
      </svg>
      {/* prozhektor nuri */}
      <div style={{position: 'absolute', left: 140, top: -60, width: 800, height: 1520, opacity: 0.55 * light,
        background: 'linear-gradient(180deg, rgba(255,226,180,.55), rgba(255,200,150,.10) 70%, rgba(255,200,150,0))',
        clipPath: 'polygon(44% 0, 56% 0, 96% 100%, 4% 100%)', filter: 'blur(14px)'}} />
      <div style={{position: 'absolute', left: 190, top: 1275, width: 700, height: 150, borderRadius: '50%', opacity: light, background: 'radial-gradient(closest-side, rgba(255,215,160,.5), rgba(255,215,160,0))'}} />
      {Array.from({length: 26}).map((_, i) => {
        const x = 300 + ((i * 137) % 480) + Math.sin(f / 40 + i) * 20, yy = ((i * 211 + f * (0.6 + (i % 5) * 0.15)) % 1300) + 80;
        return <div key={i} style={{position: 'absolute', left: x, top: 1400 - yy, width: 4 + (i % 3) * 2, height: 4 + (i % 3) * 2, borderRadius: 4, background: '#FFE3B8', opacity: 0.25 * light * (0.5 + 0.5 * Math.sin(f / 15 + i))}} />;
      })}
    </>
  );
};
const Vignette = () => <div style={{position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at 50% 45%, rgba(0,0,0,0) 45%, rgba(0,0,0,.65) 100%)', pointerEvents: 'none'}} />;

// ───────── umumiy bloklar ─────────
const Pill = ({children, bg = 'rgba(0,0,0,.55)', color = CREAM, border = 'rgba(255,255,255,.15)'}) => (
  <div style={{background: bg, color, border: `2px solid ${border}`, fontFamily: MONO, fontWeight: 800, fontSize: 22, letterSpacing: 1.5, padding: '8px 18px', borderRadius: 14}}>{children}</div>
);
const Card = ({children, x = 120, y = 330, w = 840, h, bg = CREAM, style}) => (
  <div style={{position: 'absolute', left: x, top: y, width: w, height: h, background: bg, borderRadius: 26, boxShadow: '0 30px 80px rgba(0,0,0,.55), 0 0 0 2px rgba(255,255,255,.06)', overflow: 'hidden', ...style}}>{children}</div>
);
const WinBar = ({title, dark}) => (
  <div style={{height: 44, display: 'flex', alignItems: 'center', gap: 9, padding: '0 18px', background: dark ? '#231A16' : '#EADCC8'}}>
    {['#FF5F57', '#FEBC2E', '#28C840'].map((c) => <div key={c} style={{width: 13, height: 13, borderRadius: 7, background: c}} />)}
    <div style={{flex: 1, textAlign: 'center', fontFamily: MONO, fontSize: 17, color: dark ? '#9B8B7A' : '#8A7762', marginRight: 50}}>{title}</div>
  </div>
);
// kinetik so'z: urilib tushadi
const Slam = ({f, at, children, size = 120, color = CREAM, font = FONT, rot = 0, style}) => {
  if (f < at) return null;
  const p = pop(f, at, 260, 11), sc = interpolate(p, [0, 1], [2.4, 1]);
  return <div style={{display: 'inline-block', fontFamily: font, fontWeight: 900, fontSize: size, color, lineHeight: 0.95, letterSpacing: -3, transform: `scale(${sc}) rotate(${rot}deg)`, opacity: Math.min(1, (f - at) / 3), textShadow: '0 8px 30px rgba(0,0,0,.5)', ...style}}>{children}</div>;
};
const Rise = ({f, at, children, style}) => {
  if (f < at) return null;
  const p = pop(f, at);
  return <div style={{opacity: Math.min(1, (f - at) / 4), transform: `translateY(${(1 - p) * 40}px)`, ...style}}>{children}</div>;
};
const ClaudeLogo = ({s = 120}) => <div style={{width: s, height: s, borderRadius: s * 0.26, background: RUST, display: 'grid', placeItems: 'center', color: '#fff', fontSize: s * 0.7, fontWeight: 900, boxShadow: '0 12px 40px rgba(210,105,74,.5)'}}>✳</div>;
const IGLogo = ({s = 120}) => (
  <div style={{width: s, height: s, borderRadius: s * 0.27, background: 'linear-gradient(135deg,#FEDA75,#FA7E1E,#D62976,#962FBF,#4F5BD5)', display: 'grid', placeItems: 'center', boxShadow: '0 12px 40px rgba(214,41,118,.45)'}}>
    <div style={{width: s * 0.52, height: s * 0.52, border: `${s * 0.065}px solid #fff`, borderRadius: s * 0.16, position: 'relative'}}><div style={{position: 'absolute', left: '50%', top: '50%', width: s * 0.2, height: s * 0.2, marginLeft: -s * 0.1 - s * 0.055, marginTop: -s * 0.1 - s * 0.055, border: `${s * 0.055}px solid #fff`, borderRadius: '50%'}} /></div>
  </div>
);
// piksel parchalanish (bloklar sochiladi)
const Shatter = ({f, at, x, y, w, h, color = CREAM, n = 40}) => {
  if (f < at || f > at + 26) return null;
  const k = (f - at) / 26;
  return <>{Array.from({length: n}).map((_, i) => {
    const a = (i * 2.399) % (Math.PI * 2), sp = 120 + ((i * 73) % 300);
    return <div key={i} style={{position: 'absolute', left: x + ((i * 37) % w) + Math.cos(a) * sp * k, top: y + ((i * 53) % h) + Math.sin(a) * sp * k + 400 * k * k, width: 18, height: 18, background: i % 3 ? color : RED, opacity: 1 - k, transform: `rotate(${i * 30 + k * 200}deg)`}} />;
  })}</>;
};
const Cubes = ({f, at, n = 34, colors = [RUST, LIME, CREAM, '#0B0B0F']}) => {
  if (f < at || f > at + 40) return null;
  const k = (f - at) / 40;
  return <>{Array.from({length: n}).map((_, i) => {
    const a = (i / n) * Math.PI * 2 + i, sp = 200 + (i * 59) % 300;
    return <div key={i} style={{position: 'absolute', left: 540 + Math.cos(a) * sp * k, top: 900 + Math.sin(a) * sp * k * 0.7 + 600 * k * k, width: 24, height: 24, background: colors[i % colors.length], transform: `rotate(${i * 40 + k * 300}deg)`, opacity: 1 - k * 0.9, zIndex: 40}} />;
  })}</>;
};

// ───────── sahnalar ─────────
// S1 hook: Claude + Instagram, "PROMPTI QANAQA?", izohlar yog'iladi, NOTO'G'RI SAVOL
const SHook = ({f}) => {
  const p0 = pop(f, 0, 200, 12), bad = gs(2);
  const shake = f >= bad && f < bad + 10 ? Math.sin(f * 3) * (10 - (f - bad)) * 2 : 0;
  const bubbles = [['qaysi prompt?', 150, 640, -6], ['promptini tashla 🙏', 560, 600, 5], ['prompt kerak!', 120, 760, 4], ['bu qanday prompt?', 520, 770, -4], ['prompt?? 👀', 330, 700, 2]];
  return (
    <div style={{transform: `translateX(${shake}px)`}}>
      <div style={{position: 'absolute', top: 330, left: 0, width: 1080, display: 'flex', justifyContent: 'center', alignItems: 'center'}}>
        <div style={{transform: `scale(${p0}) rotate(${(1 - p0) * -20}deg)`}}><ClaudeLogo s={130} /></div>
        <div style={{width: 300, height: 10, margin: '0 18px', background: 'rgba(255,255,255,.12)', borderRadius: 5, position: 'relative', overflow: 'visible'}}>
          <div style={{position: 'absolute', top: -9, left: ((f * 11) % 300) - 14, width: 28, height: 28, borderRadius: 14, background: LIME, boxShadow: `0 0 26px ${LIME}`}} />
        </div>
        <div style={{transform: `scale(${p0}) rotate(${(1 - p0) * 20}deg)`}}><IGLogo s={130} /></div>
      </div>
      <div style={{position: 'absolute', top: 500, left: 0, width: 1080, textAlign: 'center'}}>
        <Slam f={f} at={ws(0, 0)} size={118}>PROMPTI</Slam>{' '}
        <div />
        <Slam f={f} at={ws(0, 1)} size={118} color={GOLD} font={SERIF} rot={-3} style={{fontStyle: 'italic', letterSpacing: -2}}>qanaqa?</Slam>
      </div>
      {f < bad + 2 && bubbles.map(([t, x, y, r], i) => {
        const at = gs(1) + i * 5;
        if (f < at) return null;
        const p = pop(f, at, 220, 12);
        return <div key={i} style={{position: 'absolute', left: x, top: y + 260, transform: `scale(${p}) rotate(${r}deg)`, background: '#fff', color: '#111', fontWeight: 800, fontSize: 30, padding: '12px 22px', borderRadius: 26, boxShadow: '0 12px 30px rgba(0,0,0,.4)'}}>{t}</div>;
      })}
      <Shatter f={f} at={bad} x={120} y={860} w={820} h={260} color="#fff" n={46} />
      {f >= bad && (
        <div style={{position: 'absolute', top: 900, left: 0, width: 1080, textAlign: 'center'}}>
          <Slam f={f} at={bad} size={104} color={RED} rot={-4}>NOTO'G'RI</Slam><div />
          <Slam f={f} at={ws(2, 1)} size={104} color={CREAM} rot={-4}>SAVOL.</Slam>
        </div>
      )}
    </div>
  );
};
// S2: Men Claude / do'ppili / montaj qilmagan / men yasadim
const SIntro = ({f}) => {
  const ed = gs(5), me = gs(6);
  return (
    <>
      {f < ed && <Rise f={f} at={gs(3)} style={{position: 'absolute', top: 360, left: 0, width: 1080, textAlign: 'center'}}>
        <div style={{fontFamily: MONO, fontSize: 28, color: '#C9B8A6', letterSpacing: 4}}>SALOM, MEN</div>
        <Slam f={f} at={ws(3, 1)} size={150} color={RUST}>Claude</Slam>
      </Rise>}
      {f >= gs(4) && f < ed && <Rise f={f} at={ws(4, 1)} style={{position: 'absolute', top: 600, left: 0, width: 1080, textAlign: 'center'}}>
        <span style={{fontFamily: SERIF, fontStyle: 'italic', fontSize: 64, color: GOLD}}>do'ppili</span><span style={{fontSize: 64, fontWeight: 900, color: CREAM}}> Claude 🇺🇿</span>
      </Rise>}
      {f >= ed && (
        <Card x={140} y={600} w={800} h={190} bg="#1E1714" style={{opacity: pop(f, ed)}}>
          <WinBar title="montaj · timeline" dark />
          <div style={{position: 'relative', height: 146, padding: '18px 22px'}}>
            {[0, 1, 2].map((r) => <div key={r} style={{height: 26, marginBottom: 12, display: 'flex', gap: 6}}>
              {Array.from({length: 7}).map((_, i) => <div key={i} style={{flex: 1 + ((i * 7 + r) % 3), background: ['#5B8CFF', '#B48CFF', '#FFB347'][r], opacity: 0.75, borderRadius: 5}} />)}
            </div>)}
            <div style={{position: 'absolute', top: 12, bottom: 12, left: 22 + ((f - ed) * 9) % 740, width: 3, background: RED}} />
            {f >= ws(5, 3) && <div style={{position: 'absolute', inset: 0, display: 'grid', placeItems: 'center', background: 'rgba(0,0,0,.45)'}}>
              <Slam f={f} at={ws(5, 3)} size={60} color={RED} rot={-5}>✗ MONTAJCHI YO'Q</Slam>
            </div>}
          </div>
        </Card>
      )}
      {f >= me && <div style={{position: 'absolute', top: 360, left: 0, width: 1080, textAlign: 'center'}}>
        <Slam f={f} at={ws(6, 1)} size={96} color={LIME} rot={-3} style={{background: '#0B0B0F', padding: '6px 24px', borderRadius: 18}}>MEN YASADIM</Slam>
      </div>}
      <Cubes f={f} at={ws(6, 2)} />
    </>
  );
};
// S3: oddiy prompt → zerikarli video
const SBoring = ({f}) => {
  const a = gs(7), send = gs(8), out = gs(9);
  const prompt = 'zo\'r reels qilib ber';
  return (
    <>
      <Card x={120} y={330} w={840} h={470} bg="#1C1613">
        <WinBar title="claude · chat" dark />
        <div style={{padding: '26px 30px', position: 'relative', height: 420}}>
          <div style={{display: 'flex', justifyContent: 'flex-end'}}>
            <div style={{background: '#3A2E27', color: CREAM, fontSize: 34, fontWeight: 700, padding: '14px 24px', borderRadius: 22, maxWidth: 600}}>
              {f < send ? typed(prompt, f, a + 6, 22) : prompt}{f < send && Math.floor(f / 8) % 2 === 0 && <span style={{color: RUST}}>|</span>}
            </div>
          </div>
          {f >= send && f < out && <div style={{marginTop: 30, fontFamily: MONO, fontSize: 28, color: '#9B8B7A'}}>{['⠋', '⠙', '⠹', '⠸'][Math.floor(f / 4) % 4]} video yasalyapti…</div>}
          {f >= out && (
            <div style={{marginTop: 26, width: 420, height: 236, borderRadius: 18, background: '#6E6A66', filter: 'grayscale(1)', position: 'relative', overflow: 'hidden', transform: `scale(${pop(f, out)})`, transformOrigin: 'left top'}}>
              <div style={{position: 'absolute', left: 30, top: 30, width: 220, height: 22, background: '#8D8985', borderRadius: 6}} />
              <div style={{position: 'absolute', left: 30, top: 70, width: 300, height: 14, background: '#8D8985', borderRadius: 6}} />
              <div style={{position: 'absolute', left: 30, top: 96, width: 260, height: 14, background: '#8D8985', borderRadius: 6}} />
              <div style={{position: 'absolute', right: 26, bottom: 18, fontSize: 60}}>😴</div>
              <div style={{position: 'absolute', left: 30, bottom: 22, fontFamily: MONO, fontSize: 20, color: '#ddd'}}>video_final.mp4</div>
            </div>
          )}
          {f >= ws(9, 3) && <div style={{position: 'absolute', right: 40, top: 200}}><Slam f={f} at={ws(9, 3)} size={78} color="#BDB6AE" rot={8} style={{border: '8px solid #BDB6AE', padding: '6px 18px', borderRadius: 14}}>ZERIKARLI</Slam></div>}
        </div>
      </Card>
      {f >= gs(10) && <div style={{position: 'absolute', top: 720, left: 0, width: 1080, textAlign: 'center'}}><Rise f={f} at={gs(10)}><span style={{fontFamily: SERIF, fontStyle: 'italic', fontSize: 52, color: '#C9B8A6'}}>tan olaman…</span></Rise></div>}
    </>
  );
};
// S4: Farqi → REJISSYORDA (klaket) → SKILL.md yoziladi
const Clapper = ({f, at}) => {
  const open = f < at + 6 ? interpolate(f, [at - 10, at + 4], [0, -28], cl) : interpolate(f, [at + 4, at + 8], [-28, 0], cl);
  return (
    <div style={{position: 'relative', width: 300, height: 220}}>
      <div style={{position: 'absolute', left: 0, top: 50, width: 300, height: 170, background: '#111', borderRadius: 10, border: '4px solid #eee'}}>
        <div style={{color: '#eee', fontFamily: MONO, fontSize: 22, padding: '18px 20px', lineHeight: 1.6}}>SAHNA: 01<br />REJISSYOR: Claude</div>
      </div>
      <div style={{position: 'absolute', left: 0, top: 10, width: 300, height: 44, transformOrigin: '8px 44px', transform: `rotate(${open}deg)`, background: 'repeating-linear-gradient(-45deg,#111 0 26px,#eee 26px 52px)', borderRadius: 6, border: '4px solid #eee'}} />
    </div>
  );
};
const SDirector = ({f}) => {
  const rej = gs(12), sk = gs(13);
  const lines = ['# Reels rejissyor', '- hook: birinchi 3 soniya', '- har 2 soniyada yangi sahna', '- subtitr so\'zma-so\'z', '- ovoz + musiqa + effekt'];
  return (
    <>
      {f < sk && <Rise f={f} at={gs(11)} style={{position: 'absolute', top: 360, left: 0, width: 1080, textAlign: 'center', fontFamily: MONO, fontSize: 34, color: '#C9B8A6', letterSpacing: 3}}>FARQI BITTA NARSADA:</Rise>}
      {f >= rej - 12 && f < sk && <div style={{position: 'absolute', top: 430, left: 390, transform: `scale(${pop(f, rej - 12)}) rotate(-6deg)`}}><Clapper f={f} at={rej} /></div>}
      {f >= rej && f < sk && <div style={{position: 'absolute', top: 680, left: 0, width: 1080, textAlign: 'center'}}><Slam f={f} at={rej} size={130} color={GOLD} rot={-2}>REJISSYORDA</Slam></div>}
      {f >= sk && (
        <Card x={140} y={340} w={800} h={430} bg={CREAM} style={{transform: `translateY(${(1 - pop(f, sk)) * 300}px) rotate(${(1 - pop(f, sk)) * 8}deg)`}}>
          <WinBar title="~/.claude/skills/reels-rejissyor/SKILL.md" />
          <div style={{padding: '24px 34px', fontFamily: MONO, fontSize: 31, lineHeight: 1.55, color: INK}}>
            {lines.map((l, i) => {
              const at = sk + 10 + i * 14;
              return f >= at && <div key={i} style={{color: i === 0 ? RUST : INK, fontWeight: i === 0 ? 900 : 600}}>{typed(l, f, at, 60)}</div>;
            })}
          </div>
          <div style={{position: 'absolute', right: 26, bottom: 22, fontFamily: MONO, fontSize: 20, color: '#8A7762'}}>yozdi: Mashrabbek ✍️</div>
        </Card>
      )}
    </>
  );
};
// S5: qoidalar — 4 karta
const SRules = ({f}) => {
  const R = [
    [gs(14), 'HOOK', 'birinchi 3 soniya', RUST],
    [gs(15), 'SAHNA', 'har 2 soniyada yangi', '#5B8CFF'],
    [gs(16), 'SUBTITR', "so'zma-so'z", LIME],
    [gs(17), 'OVOZ · MUSIQA · SFX', 'hammasi ichida', GOLD],
  ];
  const cur = R.filter((r) => f >= r[0]).length - 1;
  const [at, title, sub, col] = R[Math.max(0, cur)];
  const energy = (lip[f] || [0])[0];
  return (
    <>
      <div style={{position: 'absolute', top: 335, left: 120, display: 'flex', gap: 10}}>
        {R.map((r, i) => <div key={i} style={{width: 60, height: 10, borderRadius: 5, background: i <= cur ? r[3] : 'rgba(255,255,255,.15)'}} />)}
      </div>
      <Card key={cur} x={120} y={370} w={840} h={420} bg="#17110F" style={{transform: `translateX(${(1 - pop(f, at)) * 900}px)`, border: `3px solid ${col}`}}>
        <div style={{padding: '30px 40px'}}>
          <div style={{fontFamily: MONO, fontSize: 24, color: col, letterSpacing: 3}}>QOIDA {cur + 1}/4</div>
          <div style={{fontSize: 74, fontWeight: 900, color: CREAM, marginTop: 6, letterSpacing: -2}}>{title}</div>
          <div style={{fontFamily: SERIF, fontStyle: 'italic', fontSize: 44, color: col}}>{sub}</div>
          <div style={{marginTop: 26, height: 150, position: 'relative'}}>
            {cur === 0 && (() => { const k = interpolate(f, [at + 6, at + 90], [0, 1], cl); return (
              <div style={{display: 'flex', alignItems: 'center', gap: 30}}>
                <svg width="150" height="150" viewBox="0 0 150 150"><circle cx="75" cy="75" r="60" fill="none" stroke="#3A2C25" strokeWidth="14" /><circle cx="75" cy="75" r="60" fill="none" stroke={RUST} strokeWidth="14" strokeLinecap="round" strokeDasharray={377} strokeDashoffset={377 * (1 - k)} transform="rotate(-90 75 75)" /></svg>
                <div style={{fontSize: 110, fontWeight: 900, color: CREAM}}>{Math.min(3, Math.floor(k * 3) + 1)}s</div>
              </div>); })()}
            {cur === 1 && <div style={{display: 'flex', gap: 14}}>{[0, 1, 2, 3].map((i) => {
              const on = Math.floor((f - at) / 9) % 4 === i;
              return <div key={i} style={{width: 170, height: 140, borderRadius: 14, background: ['#3B5BDB', '#C2255C', '#2B8A3E', '#E8590C'][i], opacity: on ? 1 : 0.35, transform: `scale(${on ? 1.06 : 0.94})`}} />;
            })}</div>}
            {cur === 2 && <div style={{display: 'flex', gap: 18, fontSize: 56, fontWeight: 900}}>{['har', 'bir', "so'z", 'yonadi'].map((w, i) => {
              const k = Math.floor((f - at) / 8) % 5;
              return <span key={i} style={{color: k === i ? LIME : k > i ? CREAM : 'rgba(255,255,255,.3)'}}>{w}</span>;
            })}</div>}
            {cur === 3 && <div style={{display: 'flex', alignItems: 'flex-end', gap: 9, height: 140}}>{Array.from({length: 28}).map((_, i) => {
              const h = 14 + (Math.abs(Math.sin(f / 4 + i * 0.7)) * 0.5 + energy) * 110;
              return <div key={i} style={{width: 18, height: Math.min(140, h), borderRadius: 6, background: i % 3 === 0 ? GOLD : i % 3 === 1 ? RUST : LIME}} />;
            })}</div>}
          </div>
        </div>
      </Card>
    </>
  );
};
// S6: rejissyordek — ssenariy, sahna, ovoz
const SCrew = ({f}) => {
  const items = [[gs(19), 'SSENARIY', '📝', RUST], [gs(20), 'SAHNALAR', '🎬', '#5B8CFF'], [gs(21), 'OVOZGA MOS', '🎙️', LIME]];
  return (
    <>
      <Rise f={f} at={gs(18)} style={{position: 'absolute', top: 340, left: 0, width: 1080, textAlign: 'center'}}>
        <span style={{fontSize: 58, fontWeight: 900, color: CREAM}}>rejissyordek </span><span style={{fontFamily: SERIF, fontStyle: 'italic', fontSize: 62, color: GOLD}}>o'ylayman</span>
      </Rise>
      <div style={{position: 'absolute', top: 450, left: 90, width: 900, display: 'flex', gap: 24}}>
        {items.map(([at, t, ic, c], i) => f >= at && (
          <div key={i} style={{flex: 1, height: 330, borderRadius: 24, background: '#17110F', border: `3px solid ${c}`, padding: 22, transform: `translateY(${(1 - pop(f, at)) * 260}px) rotate(${(1 - pop(f, at)) * (i - 1) * 12}deg)`, boxShadow: '0 20px 50px rgba(0,0,0,.5)'}}>
            <div style={{fontSize: 70}}>{ic}</div>
            <div style={{fontSize: 34, fontWeight: 900, color: c, marginTop: 6}}>{t}</div>
            <div style={{marginTop: 16}}>
              {i === 0 && [0, 1, 2, 3].map((k) => <div key={k} style={{height: 12, borderRadius: 6, background: '#3A2C25', marginBottom: 12, width: `${Math.min(100, Math.max(0, (f - at - k * 6) * 5))}%`, maxWidth: [100, 80, 92, 60][k] + '%'}} />)}
              {i === 1 && <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8}}>{[0, 1, 2, 3].map((k) => <div key={k} style={{height: 56, borderRadius: 8, background: ['#3B5BDB', '#C2255C', '#2B8A3E', '#E8590C'][k], opacity: f >= at + k * 6 ? 1 : 0.15}} />)}</div>}
              {i === 2 && <div style={{display: 'flex', alignItems: 'center', gap: 4, height: 110}}>{Array.from({length: 18}).map((_, k) => <div key={k} style={{width: 8, height: 10 + Math.abs(Math.sin(k * 1.3 + f / 5)) * 80, borderRadius: 4, background: LIME}} />)}</div>}
            </div>
          </div>
        ))}
      </div>
    </>
  );
};
// S7: isbot — render taymeri
const SProof = ({f}) => {
  const a = gs(22), b = gs(23);
  const k = interpolate(f, [b, b + 50], [0, 1], cl);
  const sec = Math.round(k * 227), mm = String(Math.floor(sec / 60)).padStart(2, '0'), ss = String(sec % 60).padStart(2, '0');
  return (
    <Card x={140} y={340} w={800} h={440} bg="#100B0A" style={{border: '3px solid #2E231E'}}>
      <WinBar title="render.sh · reel.mp4" dark />
      <div style={{padding: '26px 36px', textAlign: 'center'}}>
        <Rise f={f} at={a}><div style={{display: 'inline-block', background: RUST, color: '#fff', fontWeight: 900, fontSize: 34, padding: '8px 22px', borderRadius: 14}}>36 SONIYALIK VIDEO</div></Rise>
        <div style={{fontFamily: MONO, fontWeight: 900, fontSize: 150, color: k >= 1 ? LIME : CREAM, letterSpacing: -4, marginTop: 14}}>{mm}:{ss}</div>
        <div style={{height: 22, borderRadius: 11, background: '#2E231E', overflow: 'hidden', marginTop: 8}}><div style={{width: `${k * 100}%`, height: '100%', background: k >= 1 ? LIME : RUST}} /></div>
        <div style={{fontFamily: MONO, fontSize: 24, color: '#9B8B7A', marginTop: 16}}>{k >= 1 ? '✓ TAYYOR · haqiqiy render vaqti' : 'render qilinyapti…'}</div>
      </div>
    </Card>
  );
};
// S8: ko'p qismi Claude, g'oya sizdan
const SSplit = ({f}) => {
  const a = gs(24), b = gs(25);
  const k = interpolate(f, [a + 6, a + 30], [0, 1], cl);
  return (
    <div style={{position: 'absolute', top: 400, left: 120, width: 840}}>
      <div style={{display: 'flex', height: 160, borderRadius: 24, overflow: 'hidden', boxShadow: '0 20px 60px rgba(0,0,0,.5)'}}>
        <div style={{width: `${75 * k}%`, background: RUST, display: 'grid', placeItems: 'center', color: '#fff', fontWeight: 900, fontSize: 44}}>{k > 0.6 && '✳ Claude'}</div>
        <div style={{flex: 1, background: f >= b ? LIME : '#2E231E', display: 'grid', placeItems: 'center', color: INK, fontWeight: 900, fontSize: 40}}>{f >= b && 'SIZ'}</div>
      </div>
      <div style={{display: 'flex', justifyContent: 'space-between', marginTop: 18, fontFamily: MONO, fontSize: 26, color: '#C9B8A6'}}>
        <span>ishning ko'p qismi</span>{f >= b && <span style={{color: LIME}}>g'oya + did 💡</span>}
      </div>
    </div>
  );
};
// S9: CTA — izoh, direkt, DARS
const SCta = ({f}) => {
  const a = gs(26), dm = gs(27), q2 = gs(28), d2 = gs(29);
  const t1 = typed('SKILL', f, ws(26, 1), 10), sent1 = f >= ws(26, 3);
  const t2 = typed('DARS', f, ws(29, 0), 12), sent2 = f >= ws(29, 2);
  const Field = ({text, sent, y}) => (
    <div style={{position: 'absolute', left: 120, top: y, width: 840, display: 'flex', alignItems: 'center', gap: 18, background: '#fff', borderRadius: 44, padding: '18px 26px', boxShadow: '0 16px 40px rgba(0,0,0,.45)'}}>
      <div style={{width: 56, height: 56, borderRadius: 28, background: 'linear-gradient(135deg,#FEDA75,#D62976,#4F5BD5)'}} />
      <div style={{flex: 1, fontSize: 46, fontWeight: 900, color: INK}}>{text}{!sent && Math.floor(f / 8) % 2 === 0 && <span style={{color: RUST}}>|</span>}</div>
      <div style={{background: sent ? '#2FBF71' : '#4F5BD5', color: '#fff', fontWeight: 900, fontSize: 26, padding: '10px 22px', borderRadius: 22}}>{sent ? '✓' : 'Joylash'}</div>
    </div>
  );
  return (
    <>
      <Rise f={f} at={a} style={{position: 'absolute', top: 335, left: 120, fontFamily: MONO, fontSize: 24, color: '#C9B8A6', letterSpacing: 3}}>IZOHGA YOZING 👇</Rise>
      {f >= a && <Field text={sent1 ? 'SKILL' : t1} sent={sent1} y={380} />}
      {f >= dm && <div style={{position: 'absolute', left: 300, top: 520, width: 660, transform: `translateY(${(1 - pop(f, dm)) * 40}px)`, opacity: pop(f, dm)}}>
        <div style={{background: '#3797F0', color: '#fff', borderRadius: 30, padding: '18px 26px', fontSize: 32, fontWeight: 800}}>🎁 Bepul versiya direktingizda</div>
        <div style={{marginTop: 10, background: '#262626', color: '#fff', borderRadius: 22, padding: '14px 22px', fontSize: 26, fontFamily: MONO, display: 'inline-block'}}>📦 reels-rejissyor-lite.zip</div>
      </div>}
      {f >= q2 && <Field text={sent2 ? 'DARS' : t2} sent={sent2} y={700} />}
      {f >= q2 && <div style={{position: 'absolute', right: 110, top: 668, background: GOLD, color: INK, fontWeight: 900, fontSize: 24, padding: '6px 16px', borderRadius: 12, transform: `rotate(6deg) scale(${pop(f, q2)})`}}>2-QISM</div>}
    </>
  );
};
const SCENES = [
  [0, gs(3) - 4, SHook, 'HOOK'],
  [gs(3) - 4, gs(7) - 3, SIntro, 'TANISHUV'],
  [gs(7) - 3, gs(11) - 3, SBoring, 'MUAMMO'],
  [gs(11) - 3, gs(14) - 3, SDirector, 'YECHIM'],
  [gs(14) - 3, gs(18) - 3, SRules, 'QOIDALAR'],
  [gs(18) - 3, gs(22) - 3, SCrew, 'JARAYON'],
  [gs(22) - 3, gs(24) - 3, SProof, 'ISBOT'],
  [gs(24) - 3, gs(26) - 3, SSplit, '75 / 25'],
  [gs(26) - 3, DUR, SCta, 'SKILL · DARS'],
];
// Mascot pozalari: [boshlanish, tugash, poza]
const POSES = [
  [ws(6, 1), ws(6, 1) + 36, {thL: 150, thR: 150, bdL: 8, bdR: 8}],
  [gs(10), gs(10) + 26, {thL: 40, thR: 55, bdL: 35, bdR: 35}],
  [gs(12), gs(12) + 30, {thL: 90, thR: 90, bdL: -95, bdR: -95}],
  [gs(29), DUR, {thL: 12, thR: 140, bdL: 10, bdR: 35}],
];
const POINTS = [[gs(13), gs(13) + 45], [gs(14), gs(14) + 30], [gs(19), gs(19) + 25], [gs(22), gs(22) + 30], [gs(26), gs(26) + 40]];

export const Reel: React.FC = () => {
  const f = useCurrentFrame();
  const si = SCENES.findIndex(([a, b]) => f >= a && f < b);
  const sc = SCENES[Math.max(0, si)];
  const Sc = sc[2];
  const enter = si <= 0 ? 1 : interpolate(f, [sc[0], sc[0] + 7], [0, 1], cl);
  const appear = gs(3) - 6;
  const light = interpolate(f, [appear - 4, appear + 8], [0.15, 1], cl);
  // kamera: tanishuvda yaqinlashadi, keyin orqaga; REJISSYORDA da zarb
  const zoom = interpolate(f, [appear, appear + 30, gs(7) - 10, gs(7) + 10], [1, 1.12, 1.12, 1], cl) + (f >= gs(12) && f < gs(12) + 10 ? (10 - (f - gs(12))) * 0.006 : 0);
  const cur = words.filter((w) => w.s <= f + 1).slice(-1)[0];
  const grp = cur ? words.filter((w) => w.g === cur.g) : [];
  const txt = grp.map((w) => w.d).join(' ');
  let pose, poseW = 0;
  for (const [a, b, p] of POSES) { const w = interpolate(f, [a, a + 5, b - 5, b], [0, 1, 1, 0], cl); if (w > 0) { pose = p; poseW = w; } }
  const point = Math.max(0, ...POINTS.map(([a, b]) => interpolate(f, [a, a + 6, b - 6, b], [0, 1, 1, 0], cl)));
  // piksel o'tish (sahna almashganda)
  const tr = SCENES.map((s) => s[0]).find((s) => s > 0 && f >= s - 6 && f < s + 8);
  const kk = tr ? (f - (tr - 6)) / 14 : -1;
  return (
    <AbsoluteFill style={{fontFamily: FONT, background: INK, overflow: 'hidden'}}>
      <div style={{position: 'absolute', inset: 0, transform: `scale(${zoom})`, transformOrigin: '540px 1100px'}}>
        <Room f={f} light={light} />
        <Mascot x={540} y={1335} s={1.1} yaw={-8} at={appear} lip={lip} point={point} pose={pose} poseW={poseW} doppiDelay={Math.max(13, ws(4, 1) - appear - 4)} shadow="rgba(0,0,0,.55)" />
      </div>
      <div style={{position: 'absolute', inset: 0, opacity: enter, transform: `translateY(${(1 - enter) * 14}px)`}}><Sc f={f} /></div>
      {kk >= 0 && Array.from({length: 48}).map((_, i) => {
        const cx = i % 6, cy = Math.floor(i / 6), d = ((cx * 7 + cy * 3) % 10) / 10;
        const sz = Math.max(0, Math.sin(Math.PI * Math.min(1, Math.max(0, kk * 1.5 - d * 0.5))));
        return <div key={i} style={{position: 'absolute', left: cx * 180, top: 300 + cy * 70, width: 180, height: 70, display: 'grid', placeItems: 'center', zIndex: 30}}><div style={{width: 180 * sz, height: 70 * sz, background: i % 3 === 0 ? RUST : i % 3 === 1 ? '#0B0B0F' : '#5A1A12'}} /></div>;
      })}
      <Vignette />
      <div style={{position: 'absolute', top: 250, left: 90, right: 90, display: 'flex', justifyContent: 'space-between', zIndex: 20}}>
        <Pill>● CLAUDE · REJISSYOR</Pill><Pill bg={LIME} color={INK} border={LIME}>{sc[3]}</Pill>
      </div>
      {cur && f <= cur.e + 20 && (
        <div style={{position: 'absolute', left: 0, width: 1080, bottom: 400, zIndex: 50, display: 'flex', justifyContent: 'center'}}>
          <div style={{background: '#0B0B0F', border: '2px solid rgba(255,255,255,.1)', borderRadius: 18, padding: '10px 24px', display: 'flex', gap: 14, fontWeight: 900, fontSize: txt.length > 26 ? 42 : 52, maxWidth: 840, flexWrap: 'wrap', justifyContent: 'center'}}>
            {grp.map((w, i) => <span key={i} style={{color: f >= w.s && f <= w.e + 2 ? LIME : f > w.e ? '#fff' : 'rgba(255,255,255,.35)'}}>{w.d}</span>)}
          </div>
        </div>
      )}
      {f >= gs(29) + 10 && <div style={{position: 'absolute', left: 0, width: 1080, top: 805, textAlign: 'center', zIndex: 25, opacity: pop(f, gs(29) + 10)}}>
        <span style={{background: '#0B0B0F', color: GOLD, fontFamily: MONO, fontWeight: 900, fontSize: 34, padding: '10px 26px', borderRadius: 16, border: `2px solid ${GOLD}`}}>@mashrabbek.maxmatkulov</span>
      </div>}
    </AbsoluteFill>
  );
};
// Muqova
export const Cover: React.FC = () => (
  <AbsoluteFill style={{fontFamily: FONT, background: INK, overflow: 'hidden'}}>
    <Room f={40} light={1} />
    <Mascot x={540} y={1335} s={1.1} yaw={-12} at={-120} face="smile" pose={{thL: 12, thR: 150, bdL: 10, bdR: 20}} shadow="rgba(0,0,0,.55)" />
    <Vignette />
    <div style={{position: 'absolute', top: 300, left: 0, width: 1080, textAlign: 'center'}}>
      <div style={{fontSize: 120, fontWeight: 900, color: CREAM, letterSpacing: -4, lineHeight: 0.95}}>PROMPT</div>
      <div style={{fontSize: 120, fontWeight: 900, color: RED, letterSpacing: -4, lineHeight: 0.95, whiteSpace: 'nowrap'}}>EMAS ✗</div>
      <div style={{fontFamily: SERIF, fontStyle: 'italic', fontSize: 90, color: GOLD, marginTop: 10}}>rejissyor kerak</div>
    </div>
  </AbsoluteFill>
);
