// @ts-nocheck
import React from 'react';
import {AbsoluteFill} from 'remotion';
import {Mascot} from './Mascot';
const INK = '#1A1410', RUST = '#D2694A';
const POSES = [
  ['tinch', {thL: 12, thR: 12, bdL: 10, bdR: 10}, 'smile', -10],
  ['salom', {thL: 12, thR: 140, bdL: 10, bdR: 35}, 'open', -10],
  ['tepaga ko\'rsatish', {thL: 12, thR: 165, bdL: 10, bdR: 0}, 'smile', -10],
  ['kuch', {thL: 90, thR: 90, bdL: -95, bdR: -95}, 'wow', 0],
  ['tushuntirish', {thL: 40, thR: 55, bdL: 35, bdR: 35}, 'open', -18],
  ['quvonch', {thL: 150, thR: 150, bdL: 8, bdR: 8}, 'wow', 0],
];
const MOUTHS = [['jim', [0, 0.5]], ['"a"', [0.95, 0.6]], ['"o/u"', [0.7, 0.0]], ['"e/i"', [0.45, 1]]];
const Label = ({x, y, t, fs = 28}) => <div style={{position: 'absolute', left: x - 200, top: y, width: 400, textAlign: 'center', fontWeight: 900, fontSize: fs, color: INK}}>{t}</div>;
export const Sheet: React.FC = () => (
  <AbsoluteFill style={{background: '#EADBC3', fontFamily: 'Inter, sans-serif'}}>
    <div style={{position: 'absolute', top: 60, left: 0, width: 1080, textAlign: 'center', fontWeight: 900, fontSize: 54, color: INK, letterSpacing: -1}}>DO'PPILI CLAUDE <span style={{color: RUST}}>· v3</span></div>
    <div style={{position: 'absolute', top: 130, left: 0, width: 1080, textAlign: 'center', fontFamily: 'ui-monospace, monospace', fontWeight: 800, fontSize: 22, color: '#8C7B66'}}>PERSONAJ VARAQASI · TASDIQ UCHUN</div>
    <div style={{position: 'absolute', left: 0, right: 0, top: 640, height: 60, background: '#E2CFAF'}} />
    <Mascot x={330} y={660} s={0.95} face="smile" yaw={-16} at={-80} pose={{thL: 40, thR: 55, bdL: 35, bdR: 35}} />
    <Mascot x={840} y={660} s={0.68} face="flat" yaw={-48} at={-80} pose={{thL: 12, thR: 12, bdL: 10, bdR: 10}} />
    <Label x={330} y={700} t="asosiy (3/4)" /><Label x={840} y={700} t="yon tomondan" />
    {POSES.map(([n, pose, face, yaw], i) => {
      const cx = 180 + (i % 3) * 360, cy = 1070 + Math.floor(i / 3) * 400;
      return <React.Fragment key={i}><Mascot x={cx} y={cy} s={0.55} face={face} yaw={yaw} at={-80} pose={pose} /><Label x={cx} y={cy + 14} t={n} fs={26} /></React.Fragment>;
    })}
    <div style={{position: 'absolute', top: 1560, left: 0, width: 1080, textAlign: 'center', fontFamily: 'ui-monospace, monospace', fontWeight: 800, fontSize: 22, color: '#8C7B66'}}>OG'IZ SHAKLLARI (OVOZGA QARAB)</div>
    {MOUTHS.map(([n, e], i) => {
      const cx = 135 + i * 270, cy = 1820;
      return <React.Fragment key={i}><Mascot x={cx} y={cy} s={0.42} face="smile" yaw={-6} at={-80} lip={[e]} pose={{thL: 12, thR: 12, bdL: 10, bdR: 10}} doppi={true} /><Label x={cx} y={cy + 10} t={n} fs={24} /></React.Fragment>;
    })}
  </AbsoluteFill>
);
