// @ts-nocheck
import React from 'react';
import {Composition, Still} from 'remotion';
import {Reel, Cover, DUR} from './Reel';
import {Sheet} from './Sheet';
export const Root: React.FC = () => (
  <>
    <Composition id="Reel" component={Reel} durationInFrames={DUR} fps={30} width={1080} height={1920} />
    <Still id="Sheet" component={Sheet} width={1080} height={1920} />
    <Still id="Cover" component={Cover} width={1080} height={1920} />
  </>
);
